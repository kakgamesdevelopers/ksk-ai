import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "KSK AI — Karan's Assistant for KSK Games Studio",
  description: "KSK AI is a friendly AI assistant built for the KSK Games Studio community (YouTuber Karan / kskgamesstudio). Chat, generate images, write code, solve math, talk cricket, and learn real-world concepts.",
  keywords: ["KSK AI", "KSK Games Studio", "Karan", "kskgamesstudio", "AI assistant", "chatbot", "coding", "math", "cricket", "learning"],
  authors: [{ name: "Karan — KSK Games Studio" }],
  icons: { icon: "/ksk-logo.png", apple: "/ksk-logo.png" },
  openGraph: {
    title: "KSK AI — Karan's Assistant",
    description: "Chat, image, code, math, cricket & learning — built for KSK Games Studio.",
    images: ["/ksk-logo.png"],
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "KSK AI",
    description: "Friendly AI assistant built for the KSK Games Studio community.",
    images: ["/ksk-logo.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
