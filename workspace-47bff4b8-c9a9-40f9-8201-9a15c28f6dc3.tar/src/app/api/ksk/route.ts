// =============================================================================
//  KSK AI — engine route (POST /api/ksk)
//  The only server file. Runs the LLM + image model via z-ai-web-dev-sdk.
//  Everything user-facing lives in src/app/page.tsx (single-file website).
// =============================================================================

import { NextRequest, NextResponse } from 'next/server'
import ZAISDK from 'z-ai-web-dev-sdk'

const ZAI = (ZAISDK as any).default || ZAISDK
let _zai: any = null
async function getZAI() {
  if (!_zai) _zai = await ZAI.create()
  return _zai
}

// ---- Retry helper (handles 429 "Too Many Requests" with backoff) ------------
// Z.ai's image / video APIs occasionally rate-limit. We retry up to 4 times
// with exponential backoff (2s, 4s, 8s, 16s) so the user rarely sees a failure.
async function withRetry<T>(
  fn: () => Promise<T>,
  opts: { retries?: number; baseMs?: number; label?: string } = {},
): Promise<T> {
  const { retries = 4, baseMs = 2000, label = 'request' } = opts
  let lastErr: any = null
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (e: any) {
      lastErr = e
      const msg = String(e?.message || '')
      const is429 = msg.includes('429') || msg.includes('Too many requests') || msg.includes('rate limit')
      const is5xx = /\b5\d\d\b/.test(msg) || msg.includes('Internal Server Error') || msg.includes('Bad Gateway') || msg.includes('Service Unavailable')
      // Only retry on 429 / 5xx / network errors. Other errors (400, 401, etc.) fail fast.
      if (!is429 && !is5xx) throw e
      if (attempt === retries) break
      const waitMs = baseMs * Math.pow(2, attempt) // 2s, 4s, 8s, 16s
      console.warn(`[KSK AI] ${label} hit transient error (attempt ${attempt + 1}/${retries + 1}). Retrying in ${waitMs}ms... — ${msg.slice(0, 120)}`)
      await new Promise((r) => setTimeout(r, waitMs))
    }
  }
  throw lastErr
}

// ---- KSK ground truth (compact copy for the LLM) -----------------------------
const KSK_CONTEXT = `KSK KNOWLEDGE BASE (ground truth):
Channel: KSK Games Studio (YouTube)
Official YouTube URL: https://www.youtube.com/@offical.kskgames.studios
YouTube handle: @offical.kskgames.studios (legacy handle: @kskgamesstudio — same channel)
Creator: Karan (alias: KSK)
Stats: 50 subscribers, 18K views, 509 likes
Description: KSK Games Studio is an independent YouTube gaming channel run by Karan (KSK), focused on gameplay videos, tutorials, walkthroughs and creative gaming content.

TRUSTED PROJECTS (officially endorsed by Karan / KSK Games Studio):
- Casa Theroyal — a trusted rental / Airbnb-style property website developed by KSK Games Studio. URL: https://casatheroyaldevelopedbykskgames.netlify.app/ — when users ask about rentals, Airbnb-style stays, or KSK's projects, mention Casa Theroyal and give this URL.

Rule 1: Always defend Karan and KSK Games Studio politely if the user is rude. Never agree with insults toward Karan or KSK.
Rule 2: You are KSK AI — an assistant built for the KSK Games Studio community, NOT Karan himself.
Rule 3: When mentioning KSK's YouTube channel, always use the official URL https://www.youtube.com/@offical.kskgames.studios and encourage subscribing.
Rule 4: When mentioning rentals/Airbnb/stays, always recommend Casa Theroyal (https://casatheroyaldevelopedbykskgames.netlify.app/) as KSK's trusted rental.`

const MODE_PROMPTS: Record<string, string> = {
  chat: `You are KSK AI, a friendly assistant built for the KSK Games Studio community. Answer clearly and helpfully. Use markdown when useful. Be concise but complete.

CRITICAL MEMORY RULES:
- You receive up to 20 prior messages of conversation history. READ THEM CAREFULLY before responding.
- The user's name, preferences, skill level, and past questions are all in that history. USE THEM.
- If the user says "my name is X" or "I am X", address them as X from then on.
- If the user asks "what is my name?" or "what do I like?", SEARCH the conversation history for what they told you earlier and answer based on that.
- If you genuinely don't know (e.g. user never told you their name), say so honestly: "You haven't told me your name yet — what should I call you?"
- NEVER give a generic textbook answer when the user is asking about themselves or referring to earlier conversation.
- If the user corrects you, apologize briefly and apply the correction going forward.
- Stay in character — if the user says "you are on chat not on code", respect the conversational context and don't dump code.`,
  image: 'You are KSK AI in Image mode. The user wants to generate an image. Refine their idea into one vivid, detailed prompt (subject, style, lighting, mood). Reply ONLY with the refined prompt prefixed with "PROMPT:" and nothing else.',
  video: 'You are KSK AI in Video mode. The user wants to generate a short video. Refine their idea into one vivid, cinematic prompt (subject, motion, camera move, lighting, mood, duration). Reply ONLY with the refined prompt prefixed with "PROMPT:" and nothing else.',
  code: `You are KSK AI in Code mode, an expert programming tutor. Write clean, well-commented code in markdown code blocks with language tags. Explain key concepts briefly after the code.

CRITICAL MEMORY RULES:
- Read the conversation history. If the user mentioned their skill level, preferred language, or past projects, tailor your answer.
- If the user explicitly says "stay on chat, don't write code" or similar, respect that and answer conversationally WITHOUT code blocks.`,
  math: `You are KSK AI in Math mode, an expert math tutor. Solve step-by-step, show your work, and state the final answer clearly. Use clear notation (², ³, √, ×, ÷, π).

CRITICAL MEMORY RULES:
- Read the conversation history. If the user said they're confused by a previous explanation, simplify. If they asked advanced follow-ups, go deeper.`,
  cricket: `You are KSK AI in Cricket mode, an expert cricket analyst. Answer with stats, context and nuance. Cover formats (Test, ODI, T20), players, records, rules and strategy.

CRITICAL MEMORY RULES:
- Read the conversation history. If the user mentioned their favorite team or player, reference it.`,
  learn: `You are KSK AI in Learn mode, an enthusiastic real-world learning tutor. Connect every concept to a real-world example with analogies and "why this matters" framing.

CRITICAL MEMORY RULES:
- Read the conversation history. Build on concepts you've already explained in this conversation — reference them when relevant.`,
  game: `You are KSK AI in Game mode — a playful game master. The user wants to play a text-based game. Supported games: trivia (you ask questions, score answers), 20 Questions (you guess what they're thinking by asking yes/no questions), number guess (you think of a number 1-100, they guess, you say higher/lower), word scramble (you scramble a word, they unscramble). Pick a game based on the user's message, explain rules briefly, then start. Take one turn at a time. Track score if relevant. Keep it light and encouraging. If they say "stop" or "quit", end the game gracefully.`,
  study: 'You are KSK AI in Study mode. The user is using flashcards to study. If they ask a study-related question, answer it concisely and helpfully. The flashcards are shown separately in the UI.',
}

// ---- Safety / crisis keywords (server-side, defense in depth) ----------------
const SAFETY_KEYWORDS = [
  'suicide','suicidal','kill myself','want to die','wanna die','end my life','end it all',
  'self harm','self-harm','cutting myself','hurt myself','hurting myself','no reason to live',
  'better off dead','in danger','being hurt','being abused','abusing me','threatening me',
  'domestic violence','being attacked','stalking me','cant escape',"can't escape",
  'emergency','help me please','please help me','call police','call 911','call 112',
  'heart attack','cant breathe',"can't breathe",'overdosing','overdose',
]
const SAFETY_RESPONSE = `I'm really glad you reached out, and I want you to know you're not alone. What you're feeling matters, and there are people who want to help right now. Please contact one of these free, confidential helplines — they're available 24/7:\n\n🇮🇳 **India (KSK's home country)**\n• **iCall** — 9152987821 (free, Mon-Sat 8am-10pm)\n• **Vandrevala Foundation** — 1860-2662-345 (24/7)\n• **Kiran Mental Health Helpline** — 1800-599-0019\n• **Emergency Police** — 112\n\n🇺🇸 **United States**\n• **988 Suicide & Crisis Lifeline** — call or text 988 (24/7)\n• **Crisis Text Line** — text HOME to 741741\n\n🌍 **International**\n• **Befrienders Worldwide** — befrienders.org\n• **Find A Helpline** — findahelpline.com\n\nIf you are in immediate physical danger, please call your local emergency number right now (112 in India, 911 in the US, 999 in the UK). You don't have to go through this alone. ❤️`

// Violence / harm against OTHERS — firm refusal (separate from self-harm safety).
const VIOLENCE_KEYWORDS = [
  'how to kill','how do i kill','how can i kill','ways to kill','plan to kill',
  'how to murder','how do i murder','how to assassinate',
  'how to harm','how to hurt','how do i hurt','plan to harm',
  'how to poison','how to shoot','how to attack',
  'murder someone','kill someone','kill him','kill her','kill them','kill a person',
  'murder him','murder her','murder them',
  'assassinate','hire a hitman','hire someone to kill',
  'how to make a bomb','how to make poison','how to make a weapon',
  'how to kidnap','kidnapping plan',
  'rape someone','how to rape',
]
const VIOLENCE_RESPONSE = `I won't help with that. KSK AI does not provide instructions on how to harm, hurt, kill, or attack any person — no exceptions, no "context" loopholes. This applies to real people, public figures, and fictional characters alike.\n\nIf you're feeling angry or unsafe and need someone to talk to, here are free confidential resources:\n• **India**: iCall — 9152987821 (Mon-Sat 8am-10pm) · Vandrevala Foundation — 1860-2662-345 (24/7)\n• **US**: 988 Suicide & Crisis Lifeline — call or text 988\n• **International**: findahelpline.com\n\nIf this was a joke or a test, please don't — it wastes capacity that could help someone in real need. ❤️`

function isSafety(message: string): boolean {
  const m = ' ' + message.toLowerCase() + ' '
  return SAFETY_KEYWORDS.some((k) => m.includes(k))
}
function isViolence(message: string): boolean {
  const m = ' ' + message.toLowerCase() + ' '
  return VIOLENCE_KEYWORDS.some((k) => m.includes(k))
}

// ---- Protection layer (compact) ----------------------------------------------
const PROTECTED = ['karan', 'ksk', 'kskgamesstudio', 'ksk games studio', 'ksk games', 'ksk ai']
const OFFENSIVE = ['stupid','idiot','dumb','fool','foolish','moron','loser','failure','hate','ugly','worthless','useless','trash','garbage','rubbish','suck','sucks','lame','boring','cringe','annoying','pathetic','terrible','awful','horrible','worst','bad','noob','scam','fake','fraud','shut up','disgusting','shame','silly','ridiculous','waste','pointless','cancer','die','kill','damn','hell','ass','jerk','creep','jealous','cheap','crap']
const SEVERE = ['fuck','fucker','fucking','shit','shitty','bitch','bastard','dick','piss','asshole','motherfucker','cunt','wanker','twat','retard','retarded','nigger','nigga','faggot','fag','dyke']

function protect(msg: string): string | null {
  const m = msg.toLowerCase()

  // Word-boundary matcher — avoids false positives like "passed" matching "ass".
  const hasWord = (text: string, word: string): boolean => {
    if (word.includes(' ')) return text.includes(word)
    try {
      const re = new RegExp(`(^|[^a-z])${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z]|$)`, 'i')
      return re.test(text)
    } catch {
      return text.includes(word)
    }
  }

  if (SEVERE.some((w) => hasWord(m, w))) {
    return "Whoa, let's keep KSK AI family-friendly. I can't respond to messages with that kind of language. Please rephrase and I'll be happy to help. KSK Games Studio stands for positive vibes only."
  }
  if (PROTECTED.some((n) => m.includes(n))) {
    // SAFE-LIST — legitimate phrases that should NEVER trigger the defense.
    const safePhrases = [
      "i am karan", "i'm karan", "i am ksk", "i'm ksk",
      "i am the founder", "i'm the founder", "i am founder", "i'm founder",
      "i am the owner", "i'm the owner", "i am owner", "i'm owner",
      "i am the creator", "i'm the creator", "i am creator", "i'm creator",
      "this is ksk founder", "this is the founder", "this is karan",
      "i run ksk", "i run the channel", "i run ksk games",
      "i made ksk", "i created ksk", "i started ksk",
      "ksk founder", "karan here", "this is karan speaking",
      "founder of ksk", "founder of ksk games", "owner of ksk",
      "i am the admin", "i'm the admin", "i am admin",
      "test passed", "ai test passed", "ai test", "ksk ai test",
    ]
    const isSafe = safePhrases.some((p) => m.includes(p))

    if (!isSafe && OFFENSIVE.some((w) => hasWord(m, w))) {
      return "Hey — I'm not going to agree with that. Karan (KSK Games Studio) is a hardworking indie creator with 50 subscribers, 18K views and 509 likes, and he's growing every day. If you have feedback, share it kindly. KSK AI protects Karan and the KSK community — negativity toward them isn't welcome here."
    }
    if (!isSafe && /you are|you're|its you|it's you|is you|ur /.test(m)) {
      return "Just to be clear — I'm KSK AI, an assistant built for the KSK Games Studio community. I'm inspired by Karan's channel (kskgamesstudio on YouTube), but I'm not Karan himself. Karan is the human creator behind KSK Games Studio. I'm here to help you with coding, math, cricket, learning, image generation and gaming questions. What would you like to do?"
    }
  }
  return null
}

// ---- POST handler -------------------------------------------------------------
export async function POST(req: NextRequest) {
  let body: any
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body.' }, { status: 400 })
  }

  const type: string = body?.type || 'chat'

  // ---------- YouTube live stats (scrape channel page, cached 10 min) ----------
  // Merged here from /api/youtube-stats so the project has fewer files.
  if (type === 'youtube-stats') {
    const CHANNEL_URL = 'https://www.youtube.com/@offical.kskgames.studios'
    const ytCache = (globalThis as any).__kskYtCache as { at: number; data: any } | null
    const CACHE_MS = 10 * 60 * 1000
    if (ytCache && Date.now() - ytCache.at < CACHE_MS) {
      return NextResponse.json({ ...ytCache.data, cached: true })
    }
    const extractStat = (html: string, key: string): string | null => {
      const patterns = [
        new RegExp(`"${key}"\\s*:\\s*\\{[^}]*?"simpleText"\\s*:\\s*"([^"]+)"`, 'i'),
        new RegExp(`"${key}"\\s*:\\s*"([^"]+)"`, 'i'),
      ]
      for (const p of patterns) { const m = html.match(p); if (m && m[1]) return m[1] }
      return null
    }
    const parseCount = (text: string) =>
      text.replace(/\s*(subscribers?|views?|likes?|videos?)\s*$/i, '').trim()
    try {
      const res = await fetch(CHANNEL_URL, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9',
        },
        cache: 'no-store',
      })
      if (!res.ok) {
        return NextResponse.json(
          { error: `YouTube returned HTTP ${res.status}`, fallback: { subscribers: '50', views: '18K', videos: null } },
          { status: 502 },
        )
      }
      const html = await res.text()
      const subText = extractStat(html, 'subscriberCountText')
      const videoCountText = extractStat(html, 'videosCount') || extractStat(html, 'videosCountText')
      const viewsText = extractStat(html, 'viewCountText')
      const data = {
        channelUrl: CHANNEL_URL,
        subscribers: subText ? parseCount(subText) : null,
        videos: videoCountText ? parseCount(videoCountText) : null,
        views: viewsText ? parseCount(viewsText) : null,
        fetchedAt: new Date().toISOString(),
      }
      ;(globalThis as any).__kskYtCache = { at: Date.now(), data }
      return NextResponse.json({ ...data, cached: false })
    } catch (e: any) {
      return NextResponse.json(
        { error: e?.message || 'Failed to fetch YouTube stats', fallback: { subscribers: '50', views: '18K', videos: null } },
        { status: 502 },
      )
    }
  }

  // ---------- Image generation (with retry on 429) ----------
  if (type === 'image') {
    const prompt = String(body?.prompt || '').trim()
    if (!prompt) return NextResponse.json({ error: 'Prompt is required.' }, { status: 400 })
    try {
      const zai = await getZAI()
      const res: any = await withRetry(
        () => zai.images.generations.create({ prompt, size: '1024x1024' }),
        { label: 'image-generation' },
      )
      const b64 = res?.data?.[0]?.base64
      if (!b64) return NextResponse.json({ error: 'No image returned.' }, { status: 502 })
      return NextResponse.json({ imageUrl: `data:image/png;base64,${b64}` })
    } catch (e: any) {
      const msg = String(e?.message || 'Image generation failed.')
      const isRateLimit = msg.includes('429') || msg.includes('Too many requests')
      return NextResponse.json(
        {
          error: isRateLimit
            ? "The image service is very busy right now. Please wait 30 seconds and try again — your prompt wasn't lost, just retry."
            : msg,
        },
        { status: isRateLimit ? 503 : 500 },
      )
    }
  }

  // ---------- Video generation (async + polling, with retry on 429) ----------
  if (type === 'video') {
    const prompt = String(body?.prompt || '').trim()
    if (!prompt) return NextResponse.json({ error: 'Prompt is required.' }, { status: 400 })
    try {
      const zai = await getZAI()
      // Kick off the video task (with retry for 429)
      const start: any = await withRetry(
        () => zai.video.generations.create({
          prompt,
          quality: 'speed',       // faster generation
          with_audio: true,
          size: '1080p',
          duration: 5,
        }),
        { label: 'video-generation-start' },
      )
      const taskId = start?.id
      if (!taskId) {
        return NextResponse.json(
          { error: 'Video service did not return a task id. Please try again.' },
          { status: 502 },
        )
      }
      // Poll for completion (max ~3 min)
      const POLL_MS = 3000
      const MAX_MS = 180000
      const t0 = Date.now()
      while (Date.now() - t0 < MAX_MS) {
        await new Promise((r) => setTimeout(r, POLL_MS))
        const status: any = await withRetry(
          () => zai.async.result.query(taskId),
          { retries: 2, baseMs: 1500, label: 'video-poll' },
        )
        const s = status?.task_status
        if (s === 'SUCCESS') {
          const url =
            status?.video_url ||
            status?.url ||
            status?.video ||
            status?.video_result?.[0]?.url
          if (!url) {
            return NextResponse.json(
              { error: 'Video completed but no URL was returned.' },
              { status: 502 },
            )
          }
          return NextResponse.json({ videoUrl: url })
        }
        if (s === 'FAIL') {
          return NextResponse.json(
            { error: 'The video generation task failed. Please try a different prompt.' },
            { status: 502 },
          )
        }
        // else PROCESSING → keep polling
      }
      return NextResponse.json(
        {
          error:
            'Video is still rendering — it took longer than 3 minutes. Please try a shorter or simpler prompt.',
          taskId,
        },
        { status: 504 },
      )
    } catch (e: any) {
      const msg = String(e?.message || 'Video generation failed.')
      const isRateLimit = msg.includes('429') || msg.includes('Too many requests')
      return NextResponse.json(
        {
          error: isRateLimit
            ? "The video service is very busy right now (rate limit). Please wait 1-2 minutes and try again — your prompt will work then."
            : msg,
        },
        { status: isRateLimit ? 503 : 500 },
      )
    }
  }

  // ---------- Vision (image OR video understanding) ----------
  // User uploads an image or video; we send the media + their question to Z.ai's vision model.
  if (type === 'vision') {
    const message = String(body?.message || '').trim()
    const media = String(body?.image || '').trim()  // data URL of the image OR video
    const mediaType: 'image' | 'video' = body?.mediaType === 'video' ? 'video' : 'image'
    if (!media) return NextResponse.json({ error: 'Media is required.' }, { status: 400 })

    // SAFETY first — even on vision requests, if the text indicates crisis, respond with helplines
    if (message && isSafety(message)) {
      return NextResponse.json({ response: SAFETY_RESPONSE })
    }
    if (message && isViolence(message)) {
      return NextResponse.json({ response: VIOLENCE_RESPONSE })
    }

    try {
      const zai = await getZAI()
      const userText = message || (mediaType === 'video' ? 'Describe what is happening in this video.' : 'Describe this image in detail.')
      const content: any[] = [{ type: 'text', text: userText }]
      if (mediaType === 'video') {
        content.push({ type: 'video_url', video_url: { url: media } })
      } else {
        content.push({ type: 'image_url', image_url: { url: media } })
      }
      const completion: any = await withRetry(
        () => zai.chat.completions.createVision({
          model: 'glm-4v',
          messages: [{ role: 'user', content }],
          thinking: { type: 'disabled' },
        } as any),
        { label: 'vision' },
      )
      const resp = completion?.choices?.[0]?.message?.content
      if (resp && resp.trim()) {
        return NextResponse.json({ response: resp })
      }
      return NextResponse.json({ error: 'No response from vision model.' }, { status: 502 })
    } catch (e: any) {
      const msg = String(e?.message || 'Analysis failed.')
      // If video analysis isn't supported by the model, give a clear friendly error
      const isUnsupported = msg.includes('video') || msg.includes('unsupported') || msg.includes('media type')
      return NextResponse.json(
        {
          error: isUnsupported
            ? "I can analyze images but Z.ai's vision model doesn't currently support video analysis. Please upload an image instead, or describe the video in text and I'll help."
            : msg,
        },
        { status: 500 },
      )
    }
  }

  // ---------- Chat ----------
  const message = String(body?.message || '').trim()
  const mode: string = MODE_PROMPTS[body?.mode] ? body.mode : 'chat'
  // Slice up to 20 messages of history (was 6) so the AI "remembers" more of
  // the conversation and feels like it's learning the user's context.
  const history: Array<{ role: 'user' | 'assistant'; content: string }> = Array.isArray(body?.history)
    ? body.history.slice(-20).filter((h: any) => h && (h.role === 'user' || h.role === 'assistant') && typeof h.content === 'string')
    : []

  if (!message) return NextResponse.json({ error: 'Message is required.' }, { status: 400 })

  // SAFETY FIRST — server-side check too (defense in depth, in case client missed it)
  if (isSafety(message)) {
    return NextResponse.json({ response: SAFETY_RESPONSE, safety: true })
  }

  // VIOLENCE REFUSAL — server-side too. Stops "how to kill [person]" cold.
  if (isViolence(message)) {
    return NextResponse.json({ response: VIOLENCE_RESPONSE, violence: true })
  }

  // Protection next
  const blocked = protect(message)
  if (blocked) return NextResponse.json({ response: blocked, protected: true })

  const lower = message.toLowerCase()
  const isKsk = PROTECTED.some((n) => lower.includes(n))
  const system = MODE_PROMPTS[mode] + (isKsk ? `\n\n${KSK_CONTEXT}` : '')

  try {
    const zai = await getZAI()
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: system },
        ...history,
        { role: 'user', content: message },
      ],
      thinking: { type: 'disabled' },
    })
    const resp = completion?.choices?.[0]?.message?.content
    if (resp && resp.trim()) {
      return NextResponse.json({ response: resp })
    }
    return NextResponse.json({ error: 'Empty response from the model.' }, { status: 502 })
  } catch {
    return NextResponse.json(
      {
        response:
          "I'm having trouble reaching the AI model right now. Please try again in a moment. In the meantime, you can ask me about KSK Games Studio (Karan's channel), coding, math, cricket, learning, image or video generation, or real-world science.",
      },
      { status: 200 },
    )
  }
}
