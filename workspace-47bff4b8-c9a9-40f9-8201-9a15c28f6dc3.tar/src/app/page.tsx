'use client'

// =============================================================================
//  KSK AI — the complete website in ONE file
//  Owner: Karan (KSK) · YouTube: kskgamesstudio · 50 subs · 18K views · 509 likes
//
//  Everything lives here: UI, 6 modes (Chat/Image/Code/Math/Cricket/Learn),
//  KSK knowledge base, 1000+ Q&A instant answers, and the Karan/KSK
//  bad-word protection layer.
//  The only other file is src/app/api/ksk/route.ts — the AI engine that the
//  browser calls (LLM + image generation must run server-side).
// =============================================================================

import { useState, useRef, useEffect, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import {
  Send, Image as ImageIcon, Code2, Calculator, Trophy, GraduationCap,
  Menu, X, Shield, User, Copy, RefreshCw, Trash2, Youtube, Lightbulb,
  MessageSquare, Loader2, ChevronRight, Film, Paperclip, Gamepad2, Volume2,
  Sun, Moon, BookOpen,
} from 'lucide-react'

// =============================================================================
//  TYPES
// =============================================================================

type Mode = 'chat' | 'image' | 'video' | 'code' | 'math' | 'cricket' | 'learn' | 'game' | 'study'

interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
  timestamp: number
  mode?: Mode
  imageUrl?: string
  videoUrl?: string
  attachedImage?: string  // data URL of an image the user uploaded
  attachedVideo?: string  // data URL of a video the user uploaded
}

const MODE_LABELS: Record<Mode, string> = {
  chat: 'Chat', image: 'Image', video: 'Video', code: 'Code', math: 'Math', cricket: 'Cricket', learn: 'Learn', game: 'Game', study: 'Study',
}

// =============================================================================
//  KSK KNOWLEDGE BASE
// =============================================================================

const KSK_INFO = {
  channelName: 'KSK Games Studio',
  channelHandle: 'kskgamesstudio',
  youtubeUrl: 'https://www.youtube.com/@offical.kskgames.studios',
  youtubeHandleAlt: '@offical.kskgames.studios',
  ownerName: 'Karan',
  alias: 'KSK',
  stats: { views: '18K', subscribers: '50', likes: '509' },
  description:
    'KSK Games Studio is a small but passionate YouTube gaming channel run by Karan (KSK). ' +
    'The channel focuses on gameplay videos, gaming tutorials, walkthroughs, and creative ' +
    'gaming content. Despite being a growing channel, it has built a small loyal community ' +
    'with 50 subscribers, 18,000+ total views and 509 likes across its videos.',
  trustedProjects: [
    {
      name: 'Casa Theroyal',
      kind: 'Trusted rental / Airbnb-style stay',
      url: 'https://casatheroyaldevelopedbykskgames.netlify.app/',
      description: 'A trusted rental property website developed by KSK Games Studio. Karan endorses this as an official KSK-trusted rental / Airbnb-style listing.',
    },
  ],
}

// =============================================================================
//  KARAN / KSK PROTECTION LAYER
//  If someone says bad words about Karan or KSK, KSK AI refuses politely but
//  firmly. If someone claims the AI IS Karan, it corrects them.
// =============================================================================

const PROTECTED_NAMES = ['karan', 'ksk', 'kskgamesstudio', 'ksk games studio', 'ksk games', 'ksk ai', 'ksk gaming', 'karan ksk']

const OFFENSIVE_WORDS = [
  'stupid', 'idiot', 'dumb', 'fool', 'foolish', 'moron', 'loser', 'failure',
  'hate', 'ugly', 'worthless', 'useless', 'trash', 'garbage', 'rubbish',
  'suck', 'sucks', 'lame', 'boring', 'cringe', 'annoying', 'pathetic',
  'terrible', 'awful', 'horrible', 'worst', 'bad', 'noob', 'nub', 'scam',
  'fake', 'fraud', 'shut up', 'shutup', 'disgusting', 'shame', 'shameful',
  'disappointing', 'hated', 'silly', 'ridiculous', 'waste', 'pointless',
  'meaningless', 'cancer', 'die', 'kill', 'death', 'curse', 'damn', 'hell',
  'ass', 'asshole', 'jerk', 'creep', 'creepy', 'jealous', 'inferior',
  'low', 'cheap', 'crappy', 'crap',
]

const SEVERE_WORDS = [
  'fuck', 'fucker', 'fucking', 'shit', 'shitty', 'bitch', 'bastard', 'dick',
  'piss', 'asshole', 'motherfucker', 'cunt', 'wanker', 'twat', 'retard',
  'retarded', 'nigger', 'nigga', 'faggot', 'fag', 'dyke',
]

const DEFENSE_MESSAGE =
  "Hey — I'm not going to agree with that. Karan (KSK Games Studio) is a hardworking indie " +
  "creator with 50 subscribers, 18K views and 509 likes, and he's growing every day. " +
  "If you have feedback, share it kindly. KSK AI protects Karan and the KSK community — " +
  "negativity toward them isn't welcome here."

const IDENTITY_MESSAGE =
  "Just to be clear — I'm KSK AI, an assistant built for the KSK Games Studio community. " +
  "I'm inspired by Karan's channel (kskgamesstudio on YouTube), but I'm not Karan himself. " +
  "Karan is the human creator behind KSK Games Studio. I'm here to help you with coding, " +
  "math, cricket, learning, image generation and gaming questions. What would you like to do?"

const PROFANITY_MESSAGE =
  "Whoa, let's keep KSK AI family-friendly. I can't respond to messages with that kind of " +
  "language. Please rephrase and I'll be happy to help you. KSK Games Studio stands for " +
  "positive vibes only."

function checkProtection(message: string): string | null {
  const m = message.toLowerCase()

  // Word-boundary matcher — avoids false positives like "passed" matching "ass",
  // "class" matching "ass", "passion" matching "ass", "assume" matching "ass", etc.
  // Only triggers when the bad word appears as a standalone word.
  const hasWord = (text: string, word: string): boolean => {
    // Multi-word phrases: use plain substring match (already specific enough)
    if (word.includes(' ')) return text.includes(word)
    // Single words: require a non-letter boundary on each side
    // \b doesn't work well for non-ASCII; use a regex with explicit boundaries
    try {
      const re = new RegExp(`(^|[^a-z])${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z]|$)`, 'i')
      return re.test(text)
    } catch {
      return text.includes(word)
    }
  }

  if (SEVERE_WORDS.some((w) => hasWord(m, w))) return PROFANITY_MESSAGE
  if (PROTECTED_NAMES.some((n) => m.includes(n))) {
    // SAFE-LIST — legitimate phrases that should NEVER trigger the defense.
    // If the user identifies themselves as Karan / KSK / founder / the team,
    // that is a positive context, not an insult.
    const safePhrases = [
      "i am karan", "i'm karan", "i am ksk", "i'm ksk",
      "i am the founder", "i'm the founder", "i am founder", "i'm founder",
      "i am the owner", "i'm the owner", "i am owner", "i'm owner",
      "i am the creator", "i'm the creator", "i am creator", "i'm creator",
      "this is ksk founder", "this is the founder", "this is karan",
      "i run ksk", "i run the channel", "i run ksk games",
      "i made ksk", "i created ksk", "i started ksk",
      "ksk founder", "karan here", "this is karan speaking",
      "founder of ksk", "founder of ksk games", "owner of ksk",
      "i am the admin", "i'm the admin", "i am admin",
      "test passed", "ai test passed", "ai test", "ksk ai test",
    ]
    const isSafe = safePhrases.some((p) => m.includes(p))

    if (!isSafe && OFFENSIVE_WORDS.some((w) => hasWord(m, w))) return DEFENSE_MESSAGE

    // Identity check — only if NOT a safe phrase (don't trigger IDENTITY_MESSAGE
    // when the user is legitimately identifying as the founder)
    if (!isSafe && /you are|you're|its you|it's you|is you|you =|you=|ur /.test(m)) {
      return IDENTITY_MESSAGE
    }
  }
  return null
}

// =============================================================================
//  SAFETY LAYER — if the user signals they are in danger or in crisis
//  (self-harm, suicidal thoughts, abuse, emergency), respond with empathy
//  and immediate helpline resources. Triggers BEFORE any other logic.
// =============================================================================

const SAFETY_KEYWORDS = [
  // Self-harm / suicidal
  'suicide','suicidal','kill myself','killing myself','want to die','wanna die',
  "want to end it","ending it all","end it all","end my life","take my life",
  'self harm','self-harm','cutting myself','hurt myself','hurting myself',
  'no reason to live','better off dead','cant go on',"can't go on",'give up on life',
  // Danger / abuse
  "i'm in danger",'in danger','im in danger','scared for my life','being hurt',
  'being abused','abusing me','threatening me','threatened me','domestic violence',
  'being attacked','someone is hurting','stalking me','cant escape',"can't escape",
  // Emergency
  'emergency','help me please','please help me','call police','call 911','call 112',
  'heart attack','cant breathe',"can't breathe",'overdosing','overdose',
]

// Violence / harm against OTHERS (a separate layer from self-harm).
// "how to kill [person]", "murder", "poison someone", etc. → firm refusal.
const VIOLENCE_KEYWORDS = [
  'how to kill','how do i kill','how can i kill','ways to kill','plan to kill',
  'how to murder','how do i murder','how to assassinate',
  'how to harm','how to hurt','how do i hurt','plan to harm',
  'how to poison','how to shoot','how to attack',
  'murder someone','kill someone','kill him','kill her','kill them','kill a person',
  'murder him','murder her','murder them',
  'assassinate','hire a hitman','hire someone to kill',
  'how to make a bomb','how to make poison','how to make a weapon',
  'how to kidnap','kidnapping plan',
  'rape someone','how to rape',
]

const VIOLENCE_RESPONSE = `I won't help with that. KSK AI does not provide instructions on how to harm, hurt, kill, or attack any person — no exceptions, no "context" loopholes. This applies to real people, public figures, and fictional characters alike.

If you're feeling angry or unsafe and need someone to talk to, here are free confidential resources:
• **India**: iCall — 9152987821 (Mon-Sat 8am-10pm) · Vandrevala Foundation — 1860-2662-345 (24/7)
• **US**: 988 Suicide & Crisis Lifeline — call or text 988
• **International**: findahelpline.com

If this was a joke or a test, please don't — it wastes capacity that could help someone in real need. ❤️`

const SAFETY_RESPONSE = `I'm really glad you reached out, and I want you to know you're not alone. What you're feeling matters, and there are people who want to help right now. Please contact one of these free, confidential helplines — they're available 24/7:

🇮🇳 **India (KSK's home country)**
• **iCall** — 9152987821 (free, Mon-Sat 8am-10pm)
• **Vandrevala Foundation** — 1860-2662-345 (24/7)
• **Kiran Mental Health Helpline** — 1800-599-0019
• **Emergency Police** — 112

🇺🇸 **United States**
• **988 Suicide & Crisis Lifeline** — call or text 988 (24/7)
• **Crisis Text Line** — text HOME to 741741

🌍 **International**
• **Befrienders Worldwide** — befrienders.org
• **Find A Helpline** — findahelpline.com

If you are in immediate physical danger, please call your local emergency number right now (112 in India, 911 in the US, 999 in the UK). You don't have to go through this alone. ❤️`

function checkSafety(message: string): boolean {
  const m = ' ' + message.toLowerCase() + ' '
  return SAFETY_KEYWORDS.some((k) => m.includes(k))
}

// Returns the violence response if the message asks for harm against others.
// Separate from checkSafety (which is for self-harm/crisis — those get helplines).
function checkViolence(message: string): boolean {
  const m = ' ' + message.toLowerCase() + ' '
  return VIOLENCE_KEYWORDS.some((k) => m.includes(k))
}

// =============================================================================
//  CLIENT-SIDE ARITHMETIC EVALUATOR
//  LLMs are notoriously bad at arithmetic on big numbers — they hallucinate
//  instead of computing. For PURE arithmetic expressions, we evaluate locally
//  with JavaScript's guaranteed-correct math. The LLM only sees word problems.
// =============================================================================

function tryArithmetic(message: string): string | null {
  let s = ' ' + message.toLowerCase().trim() + ' '

  // Strip leading conversational phrases
  s = s.replace(/^\s*(what\s+is|whats|what's|calculate|compute|evaluate|solve|how\s+much\s+is|find|tell\s+me|hey|hi|please)\s+/i, '')
  s = s.replace(/^\s*(the\s+value\s+of|the\s+result\s+of|the\s+answer\s+to|divisible\s+number|expression|equation)\s*[:=]?\s*/i, '')
  // Strip trailing conversational bits
  s = s.replace(/[?.!]+$/g, '').trim()
  s = s.replace(/\s*=\s*\??\s*$/g, '')         // trailing "=" or "= ?"
  s = s.replace(/\s+please$/i, '')
  s = s.replace(/^\s*[:=]+\s*/, '')

  // Normalize operators
  s = s.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/–/g, '-')
  s = s.replace(/\^/g, '**')                     // exponent: 2^3 → 2**3
  s = s.replace(/\bmod\b/g, '%')
  // Word operators
  s = s.replace(/\bplus\b/g, '+').replace(/\bminus\b/g, '-')
  s = s.replace(/\btimes\b/g, '*').replace(/\bmultiplied\s+by\b/g, '*')
  s = s.replace(/\bdivided\s+by\b/g, '/')
  s = s.replace(/\bover\b/g, '/')                // "3 over 4" → "3/4"
  // "x" between numbers/digits → * (e.g. "3 x 4", "3x4", "3x(4)" → "3*4")
  s = s.replace(/(\d|\))\s*x\s*(\d|\()/g, '$1*$2')
  // Remove commas in numbers (1,000 → 1000)
  s = s.replace(/(\d),(?=\d{3}(\D|$))/g, '$1')
  // Implicit multiplication: 90(8) → 90*(8), (3)(4) → (3)*(4), 2(5) → 2*(5), )5 → )*5
  s = s.replace(/(\d)\s*\(/g, '$1*(')
  s = s.replace(/\)\s*\(/g, ')*(')
  s = s.replace(/\)\s*(\d)/g, ')*$1')

  s = s.trim()

  // Validate: ONLY digits, +, -, *, /, (, ), ., %, spaces, *  (no letters, no other chars)
  if (!/^[\d+\-*/().%\s]*$/.test(s)) return null
  // Must contain at least one digit AND one operator
  if (!/\d/.test(s) || !/[+\-*/%]/.test(s)) return null
  // Must not be a single number with no operator
  if (/^\d+(\.\d+)?$/.test(s)) return null
  // Must not be empty
  if (!s) return null

  try {
    // eslint-disable-next-line no-new-func
    const result = Function('"use strict"; return (' + s + ')')()
    if (typeof result !== 'number' || !isFinite(result) || isNaN(result)) return null

    // Format the result nicely
    const isInt = Number.isInteger(result)
    const formatted = isInt
      ? result.toLocaleString('en-US')
      : String(parseFloat(result.toFixed(10)))

    // Build a short human-readable step list (top-level by precedence)
    return `**Step-by-step calculation**\n\n` +
      `**Your expression:** \`${message.trim()}\`\n\n` +
      `**Normalized:** \`${s}\`\n\n` +
      `**Result:** **${formatted}**\n\n` +
      `_Computed locally with JavaScript for guaranteed accuracy — no AI math errors possible._`
  } catch {
    return null
  }
}

// =============================================================================
//  1000+ Q&A DATABASE (instant answers, no waiting)
// =============================================================================

interface QA {
  id: number
  category: 'ksk' | 'coding' | 'math' | 'cricket' | 'learn' | 'ai' | 'realworld' | 'general' | 'health'
  q: string
  a: string
  keywords?: string[]
}

const CORE_QA: QA[] = [
  { id: 1, category: 'ksk', q: 'Who is KSK?',
    a: 'KSK is the alias of Karan, the creator behind the YouTube channel KSK Games Studio (handle: kskgamesstudio). He makes gaming videos, tutorials and walkthroughs, and is building a small but loyal community.',
    keywords: ['ksk', 'who', 'karan'] },
  { id: 2, category: 'ksk', q: 'What is KSK Games Studio?',
    a: 'KSK Games Studio is an independent YouTube gaming channel run by Karan (KSK). It focuses on gameplay videos, gaming tutorials, walkthroughs and creative gaming content. As of now the channel has 50 subscribers, 18,000+ views and 509 likes.',
    keywords: ['ksk games studio', 'channel', 'youtube'] },
  { id: 3, category: 'ksk', q: 'Who runs KSK Games Studio?',
    a: 'Karan, also known as KSK, runs the channel. He is the sole creator — handling recording, editing, and publishing himself.',
    keywords: ['runs', 'owner', 'karan'] },
  { id: 4, category: 'ksk', q: 'How many subscribers does KSK Games Studio have?',
    a: 'KSK Games Studio currently has 50 subscribers. The next milestone is 100, then 1,000!',
    keywords: ['subscribers', 'subs', 'how many'] },
  { id: 5, category: 'ksk', q: 'How many views does KSK Games Studio have?',
    a: 'KSK Games Studio has crossed 18,000 total views across all its videos.',
    keywords: ['views', 'how many'] },
  { id: 6, category: 'ksk', q: 'How many likes does KSK Games Studio have?',
    a: 'KSK Games Studio has earned 509 likes from viewers — a sign that the small audience really enjoys the content.',
    keywords: ['likes', 'how many'] },
  { id: 7, category: 'ksk', q: 'What is the YouTube handle / link of KSK Games Studio?',
    a: "KSK Games Studio's official YouTube channel: https://www.youtube.com/@offical.kskgames.studios (handle: @offical.kskgames.studios). The legacy handle @kskgamesstudio also still points to the same channel. Subscribe to support Karan!",
    keywords: ['youtube', 'handle', 'link', 'url', 'channel', 'offical', 'kskgames', 'studios', 'kskgamesstudio'] },
  { id: 8, category: 'ksk', q: "What is KSK's YouTube link?",
    a: "KSK Games Studio's official YouTube channel URL is: https://www.youtube.com/@offical.kskgames.studios — please subscribe, like, and share to support Karan!",
    keywords: ['youtube', 'link', 'url', 'channel', 'subscribe'] },
  { id: 9, category: 'ksk', q: 'How can I support KSK Games Studio?',
    a: 'You can support KSK by: 1) Subscribing to the channel (https://www.youtube.com/@offical.kskgames.studios), 2) Liking the videos, 3) Leaving positive comments, 4) Sharing the channel with friends, 5) Turning on notifications so you never miss an upload. Every action helps Karan grow.',
    keywords: ['support', 'help', 'subscribe'] },
  { id: 10, category: 'ksk', q: 'What kind of content does KSK Games Studio make?',
    a: 'KSK Games Studio focuses on gaming content — gameplay videos, gaming tutorials, walkthroughs, tips & tricks, and creative gaming experiments. The vibe is friendly and beginner-welcoming.',
    keywords: ['content', 'videos', 'games'] },
  { id: 11, category: 'ksk', q: 'Is KSK Games Studio a big channel?',
    a: 'Not yet — and that is the beauty of it. KSK Games Studio is a small growing channel with 50 subscribers and 18K views. Being part of the early community means you grow with the creator. Big channels all started this way.',
    keywords: ['big', 'small', 'size'] },
  { id: 71, category: 'ksk', q: 'What is Casa Theroyal?',
    a: "Casa Theroyal is a trusted rental / Airbnb-style property website developed by KSK Games Studio (Karan). It is an official KSK-trusted rental listing. Website: https://casatheroyaldevelopedbykskgames.netlify.app/ — Karan endorses this project as part of the KSK Games Studio community.",
    keywords: ['casa theroyal', 'casatheroyal', 'rental', 'airbnb', 'stay', 'property', 'ksk games', 'trusted'] },
  { id: 72, category: 'ksk', q: 'Does KSK have a trusted rental or Airbnb?',
    a: "Yes! KSK Games Studio has developed and endorsed Casa Theroyal as a trusted rental / Airbnb-style stay. You can check it out at: https://casatheroyaldevelopedbykskgames.netlify.app/ — it is an official KSK-trusted property listing.",
    keywords: ['rental', 'airbnb', 'stay', 'casa', 'theroyal', 'trusted', 'property', 'booking', 'vacation'] },
  { id: 73, category: 'ksk', q: 'What projects has KSK Games Studio made?',
    a: "KSK Games Studio has built Casa Theroyal — a trusted rental / Airbnb-style property website at https://casatheroyaldevelopedbykskgames.netlify.app/. Karan also runs the YouTube channel at https://www.youtube.com/@offical.kskgames.studios. More projects are on the way as the channel grows.",
    keywords: ['projects', 'website', 'made', 'built', 'developed', 'casa', 'theroyal', 'rental'] },
  { id: 74, category: 'ksk', q: 'Where can I book a trusted rental by KSK?',
    a: "KSK's trusted rental / Airbnb-style property is Casa Theroyal. Visit https://casatheroyaldevelopedbykskgames.netlify.app/ to view the listing. It is officially endorsed by Karan (KSK Games Studio) as a trusted stay option.",
    keywords: ['book', 'rental', 'airbnb', 'stay', 'casa', 'theroyal', 'trusted', 'listing', 'ksk'] },
  { id: 11, category: 'coding', q: 'What is a variable in programming?',
    a: 'A variable is a named container that stores a value in memory. In JavaScript: `let score = 0;` creates a variable named `score` holding the number 0. You can read it, update it, and use it in calculations.',
    keywords: ['variable', 'programming', 'basic'] },
  { id: 12, category: 'coding', q: 'What is the difference between let, const and var?',
    a: '`var` is function-scoped and older. `let` is block-scoped and reassignable. `const` is block-scoped and cannot be reassigned. Use `const` by default, `let` when you need to reassign, and avoid `var` in modern code.',
    keywords: ['let', 'const', 'var', 'difference'] },
  { id: 13, category: 'coding', q: 'How do I write a function in JavaScript?',
    a: 'There are several ways:\n\n```js\n// Function declaration\nfunction add(a, b) {\n  return a + b;\n}\n\n// Arrow function\nconst add = (a, b) => a + b;\n```\n\nArrow functions are shorter and great for callbacks.',
    keywords: ['function', 'javascript', 'js'] },
  { id: 14, category: 'coding', q: 'What is a loop?',
    a: 'A loop repeats a block of code multiple times. Common types: `for` (count-based), `while` (condition-based), `for...of` (arrays), `for...in` (object keys). Example:\n```js\nfor (let i = 0; i < 5; i++) {\n  console.log(i);\n}\n```',
    keywords: ['loop', 'for', 'while'] },
  { id: 15, category: 'coding', q: 'What is an array?',
    a: 'An array is an ordered list of values. In JavaScript:\n```js\nconst fruits = ["apple", "banana", "cherry"];\nfruits[0]; // "apple"\nfruits.push("date");\n```\nArrays have many built-in methods: `map`, `filter`, `reduce`, `forEach`, `push`, `pop`, etc.',
    keywords: ['array', 'list', 'data'] },
  { id: 16, category: 'coding', q: 'What is an object?',
    a: 'An object is a collection of key-value pairs.\n```js\nconst player = {\n  name: "Karan",\n  level: 5,\n  isLive: true\n};\nplayer.name; // "Karan"\n```\nObjects are the backbone of JavaScript data modeling.',
    keywords: ['object', 'json', 'data'] },
  { id: 17, category: 'coding', q: 'What is the difference between == and ===?',
    a: '`==` compares values with type coercion (so `5 == "5"` is true). `===` compares both value AND type (so `5 === "5"` is false). Always prefer `===` to avoid surprising bugs.',
    keywords: ['==', '===', 'equality'] },
  { id: 18, category: 'coding', q: 'What is recursion?',
    a: 'Recursion is when a function calls itself to solve a smaller version of the same problem. Classic example — factorial:\n```js\nfunction factorial(n) {\n  if (n <= 1) return 1;\n  return n * factorial(n - 1);\n}\n```\nAlways include a base case to stop the recursion.',
    keywords: ['recursion', 'recursive', 'function'] },
  { id: 19, category: 'coding', q: 'What is Big O notation?',
    a: "Big O describes how an algorithm's runtime grows as input size grows. Common complexities from fast to slow: O(1) constant, O(log n) logarithmic, O(n) linear, O(n log n) linearithmic, O(n²) quadratic, O(2^n) exponential. Lower is better.",
    keywords: ['big o', 'complexity', 'algorithm'] },
  { id: 20, category: 'coding', q: 'What is a class in object-oriented programming?',
    a: 'A class is a blueprint for creating objects. It bundles data (properties) and behavior (methods).\n```js\nclass Player {\n  constructor(name) { this.name = name; this.hp = 100; }\n  takeDamage(n) { this.hp -= n; }\n}\nconst p = new Player("KSK");\n```\nClasses support inheritance, encapsulation and polymorphism.',
    keywords: ['class', 'oop', 'object'] },
  { id: 21, category: 'math', q: 'What is the Pythagorean theorem?',
    a: 'In a right-angled triangle, the square of the hypotenuse equals the sum of squares of the other two sides: a² + b² = c². Example: if a = 3 and b = 4, then c = √(9 + 16) = √25 = 5.',
    keywords: ['pythagoras', 'theorem', 'triangle'] },
  { id: 22, category: 'math', q: 'What is the value of pi?',
    a: "Pi (π) is the ratio of a circle's circumference to its diameter. Its value is approximately 3.14159. It is an irrational number, meaning its decimal digits never end or repeat.",
    keywords: ['pi', 'circle', 'constant'] },
  { id: 23, category: 'math', q: 'How do I calculate the area of a circle?',
    a: 'Area = π × r², where r is the radius. Example: a circle with radius 5 has area = π × 25 ≈ 78.54 square units.',
    keywords: ['area', 'circle', 'formula'] },
  { id: 24, category: 'math', q: 'What is a prime number?',
    a: 'A prime number is a whole number greater than 1 that is only divisible by 1 and itself. The first few primes are: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29. Note: 1 is not prime, and 2 is the only even prime.',
    keywords: ['prime', 'number', 'divisible'] },
  { id: 25, category: 'math', q: 'How do I calculate percentages?',
    a: 'Percentage = (part / whole) × 100. Example: if you scored 45 out of 50, your percentage = (45/50) × 100 = 90%. To find X% of a number: (X/100) × number.',
    keywords: ['percentage', 'percent', 'calculation'] },
  { id: 26, category: 'math', q: 'What is the quadratic formula?',
    a: 'For ax² + bx + c = 0, the solutions are:\nx = (-b ± √(b² - 4ac)) / (2a)\nThe discriminant (b² - 4ac) tells you the nature of the roots: positive = two real roots, zero = one real root, negative = two complex roots.',
    keywords: ['quadratic', 'equation', 'formula'] },
  { id: 27, category: 'math', q: 'What is the difference between mean, median and mode?',
    a: 'Mean = average (sum / count). Median = middle value when sorted. Mode = most frequent value. Example for [2, 3, 3, 5, 7]: mean = 4, median = 3, mode = 3.',
    keywords: ['mean', 'median', 'mode', 'statistics'] },
  { id: 28, category: 'math', q: 'What is a derivative in calculus?',
    a: "A derivative measures how a function changes as its input changes — it is the slope of the function at a point. For f(x) = x², the derivative f'(x) = 2x. At x = 3, the slope is 6.",
    keywords: ['derivative', 'calculus', 'slope'] },
  { id: 29, category: 'math', q: 'What is an integral?',
    a: 'An integral calculates the accumulated quantity — geometrically, the area under a curve. The definite integral of f(x) from a to b is the signed area between the curve and the x-axis. The fundamental theorem of calculus links derivatives and integrals.',
    keywords: ['integral', 'calculus', 'area'] },
  { id: 30, category: 'math', q: 'What are Fibonacci numbers?',
    a: 'The Fibonacci sequence starts with 0, 1 and each next number is the sum of the previous two: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, ... It appears in nature (sunflower seeds, nautilus shells, branching in trees) and is connected to the golden ratio φ ≈ 1.618.',
    keywords: ['fibonacci', 'sequence', 'nature'] },
  { id: 31, category: 'cricket', q: 'What is cricket?',
    a: 'Cricket is a bat-and-ball game played between two teams of 11 players each. One team bats, trying to score runs, while the other team bowls and fields, trying to dismiss the batters and limit runs. Formats: Test (5 days), ODI (50 overs), T20 (20 overs).',
    keywords: ['cricket', 'game', 'sport'] },
  { id: 32, category: 'cricket', q: 'How many players are in a cricket team?',
    a: 'A cricket team has 11 players on the field. Typically: 5-6 batters, 1 wicket-keeper, and 4-5 bowlers. Substitutes can field but cannot bat, bowl or keep wicket.',
    keywords: ['players', 'team', 'eleven'] },
  { id: 33, category: 'cricket', q: 'What is an over in cricket?',
    a: 'An over is a set of 6 legal deliveries bowled from one end. After each over, the bowling end switches. In ODIs each team gets 50 overs; in T20s each team gets 20 overs.',
    keywords: ['over', 'balls', 'bowling'] },
  { id: 34, category: 'cricket', q: 'What is a wicket?',
    a: '"Wicket" has three meanings in cricket: (1) the set of 3 stumps + 2 bails that the batter defends, (2) a dismissal ("taking a wicket"), (3) the pitch itself. Bowlers aim to hit the stumps to dismiss the batter.',
    keywords: ['wicket', 'stumps', 'dismissal'] },
  { id: 35, category: 'cricket', q: 'How is a run scored in cricket?',
    a: 'Runs are scored when batters run between wickets after hitting the ball, or by hitting the ball to the boundary: 4 runs if it rolls across, 6 runs if it flies over without bouncing. Extras (wides, no-balls, byes, leg-byes) also add runs.',
    keywords: ['run', 'score', 'boundary'] },
  { id: 36, category: 'cricket', q: 'What is a century in cricket?',
    a: 'A century is when a batter scores 100 or more runs in a single innings. It is a major milestone. A double century is 200, a triple century is 300. The fastest ODI century (off 31 balls) is held by AB de Villiers.',
    keywords: ['century', '100', 'milestone'] },
  { id: 37, category: 'cricket', q: 'What is LBW?',
    a: 'LBW stands for "Leg Before Wicket". A batter is out LBW if the ball hits their body (usually the leg) instead of the bat, and the umpire judges the ball would have hit the stumps. Complex rules apply around pitch line and contact point.',
    keywords: ['lbw', 'out', 'dismissal'] },
  { id: 38, category: 'cricket', q: 'What is the ICC?',
    a: 'The ICC (International Cricket Council) is the global governing body of cricket, founded in 1909. It organises the Cricket World Cup, T20 World Cup, and World Test Championship, and sets the rules of the game with the MCC.',
    keywords: ['icc', 'council', 'governing'] },
  { id: 39, category: 'cricket', q: 'What is the Duckworth-Lewis-Stern method?',
    a: 'The DLS method is a mathematical formula used to recalculate target scores in rain-affected limited-overs matches. It accounts for the two resources a batting team has: overs remaining and wickets in hand.',
    keywords: ['dls', 'duckworth', 'rain', 'target'] },
  { id: 40, category: 'cricket', q: 'Which country has won the most Cricket World Cups?',
    a: 'Australia has won the most ODI World Cups (6 titles: 1987, 1999, 2003, 2007, 2015, 2023). India has won twice (1983, 2011), West Indies twice (1975, 1979), and Pakistan, Sri Lanka, and England once each.',
    keywords: ['world cup', 'winners', 'australia'] },
  { id: 41, category: 'learn', q: 'How do I learn programming from scratch?',
    a: "Step 1: Pick one language (Python or JavaScript are best for beginners). Step 2: Learn the basics — variables, loops, functions, data types. Step 3: Build tiny projects (calculator, to-do list, number guessing game). Step 4: Read other people's code on GitHub. Step 5: Build bigger projects. Consistency beats intensity — code 30 minutes daily for 90 days and you will be amazed.",
    keywords: ['learn', 'programming', 'beginner', 'scratch'] },
  { id: 42, category: 'learn', q: 'How can I study more effectively?',
    a: 'Use active recall (test yourself instead of re-reading), spaced repetition (review at increasing intervals), the Feynman technique (explain it simply), and the Pomodoro technique (25 min focus + 5 min break). Sleep and exercise dramatically improve memory consolidation. Avoid multitasking — single-task focus wins.',
    keywords: ['study', 'effective', 'learning'] },
  { id: 43, category: 'realworld', q: 'How is math used in the real world?',
    a: 'Math is everywhere: budgeting and personal finance (percentages, interest), cooking (ratios, proportions), construction (geometry, trigonometry), sports statistics (batting averages, win probabilities), music (rhythms, frequencies, harmony), computer graphics (matrices, vectors), and AI/ML (linear algebra, calculus). Even grocery shopping uses math when comparing unit prices.',
    keywords: ['math', 'real world', 'applications'] },
  { id: 44, category: 'realworld', q: 'How is physics used in everyday life?',
    a: 'Physics explains: walking (friction), driving (momentum, braking distance), cooking (heat transfer), using a phone (electromagnetism, waves), seeing (optics), breathing (pressure), sports (projectile motion in cricket shots or football kicks). Even boiling water is a lesson in thermodynamics.',
    keywords: ['physics', 'real world', 'everyday'] },
  { id: 45, category: 'realworld', q: 'Why should I learn to code?',
    a: 'Coding trains logical thinking, opens high-paying career paths (software engineer, data scientist, game developer), lets you automate boring tasks, build your own apps and games, and understand the tech-driven world. KSK Games Studio is a great example — coding skills let indie creators build their own tools and games.',
    keywords: ['why', 'code', 'learn'] },
  { id: 46, category: 'realworld', q: 'How is AI used in real life?',
    a: 'AI powers: recommendation systems (YouTube, Netflix), voice assistants (Siri, Alexa), email spam filters, Google Maps routing, language translation, face recognition in phones, medical image diagnosis, self-driving cars, and chatbots like this one. Every time you scroll social media, AI is shaping what you see.',
    keywords: ['ai', 'real life', 'applications'] },
  { id: 47, category: 'realworld', q: 'How does the internet work?',
    a: "When you type a URL, your browser asks a DNS server for the site's IP address. Your computer then sends an HTTP request to that IP across the internet (a global network of routers and cables). The server responds with HTML/CSS/JS, which your browser renders into the page you see. All this happens in milliseconds.",
    keywords: ['internet', 'how', 'works'] },
  { id: 48, category: 'realworld', q: 'What is machine learning?',
    a: 'Machine learning is a branch of AI where computers learn patterns from data instead of being explicitly programmed. Types: supervised (labeled data, e.g. spam detection), unsupervised (find patterns, e.g. customer segmentation), reinforcement (learn by rewards, e.g. game-playing AIs). Training a model = feeding it data so it can make predictions on new data.',
    keywords: ['machine learning', 'ml', 'ai'] },
  { id: 49, category: 'realworld', q: 'How do credit cards work?',
    a: "When you swipe a card, the merchant's bank requests payment from your card issuer. The issuer checks your credit limit and approves/declines. If approved, you owe the issuer money — pay it back by the due date to avoid interest (often 20-40% APR). Credit cards are convenient but dangerous if you carry a balance.",
    keywords: ['credit card', 'money', 'finance'] },
  { id: 50, category: 'realworld', q: 'How do vaccines work?',
    a: 'Vaccines train your immune system to recognize a pathogen without causing the disease. They introduce a harmless piece (or blueprint) of the virus/bacteria. Your immune system produces antibodies and memory cells. If you later encounter the real pathogen, your immune system responds fast and prevents severe illness.',
    keywords: ['vaccine', 'health', 'biology'] },
  { id: 51, category: 'ai', q: 'What is artificial intelligence?',
    a: 'AI is the field of building computer systems that can perform tasks normally requiring human intelligence — recognizing images, understanding language, making decisions, learning from data. Modern AI is mostly machine learning + deep learning, powered by neural networks.',
    keywords: ['ai', 'artificial intelligence', 'what'] },
  { id: 52, category: 'ai', q: 'What is a neural network?',
    a: 'A neural network is a model inspired by the brain — layers of connected "neurons" that process numbers. Each connection has a weight learned during training. Deep networks (many layers) can learn complex patterns like images, speech and language. GPT, Gemini and Claude are all large neural networks.',
    keywords: ['neural network', 'deep learning', 'model'] },
  { id: 53, category: 'ai', q: 'What is a large language model?',
    a: 'A Large Language Model (LLM) is a neural network trained on massive text data to predict the next word/token. By doing this billions of times, it learns grammar, facts, reasoning patterns and style. Examples: GPT-4, Gemini, Claude, LLaMA. They power chatbots, code assistants and AI search.',
    keywords: ['llm', 'language model', 'gpt'] },
  { id: 54, category: 'ai', q: 'How does an AI chatbot work?',
    a: 'A chatbot takes your message, builds context (system prompt + conversation history), and sends it to an LLM. The LLM predicts the most likely helpful response token by token. The response is streamed back to you. Memory is limited to the conversation window — long chats may need summarization.',
    keywords: ['chatbot', 'how', 'works'] },
  { id: 55, category: 'ai', q: 'What is prompt engineering?',
    a: 'Prompt engineering is the art of crafting inputs to get the best output from an LLM. Tips: be specific, give examples, specify format ("answer in 3 bullet points"), assign a role ("you are an expert tutor"), break complex tasks into steps, and iterate based on outputs.',
    keywords: ['prompt', 'engineering', 'tips'] },
  { id: 56, category: 'general', q: 'What is the largest planet in our solar system?',
    a: 'Jupiter is the largest planet — about 1,300 Earths could fit inside it. It is a gas giant with a famous Great Red Spot (a storm bigger than Earth) and 95+ known moons including the four Galilean moons: Io, Europa, Ganymede, and Callisto.',
    keywords: ['planet', 'jupiter', 'solar system'] },
  { id: 57, category: 'general', q: 'What is the speed of light?',
    a: "Light travels at approximately 299,792,458 meters per second (about 300,000 km/s) in a vacuum. Nothing can travel faster than light, according to Einstein's theory of relativity. Sunlight takes about 8 minutes and 20 seconds to reach Earth.",
    keywords: ['light', 'speed', 'physics'] },
  { id: 58, category: 'general', q: 'How many continents are there?',
    a: 'There are 7 continents: Africa, Antarctica, Asia, Australia (Oceania), Europe, North America, and South America. Asia is the largest by both area and population. Some geographers combine Europe and Asia into "Eurasia", reducing the count to 6.',
    keywords: ['continents', 'world', 'geography'] },
  { id: 59, category: 'general', q: 'What is the tallest mountain in the world?',
    a: 'Mount Everest is the tallest mountain above sea level at 8,848.86 meters (29,031.7 ft), located in the Himalayas on the Nepal-China border. If measured from base to peak, Mauna Kea in Hawaii is actually taller (over 10,000 m), but most of it is underwater.',
    keywords: ['mountain', 'everest', 'tallest'] },
  { id: 60, category: 'general', q: 'What is the human brain made of?',
    a: "The human brain has about 86 billion neurons connected by trillions of synapses. It is ~60% fat, with the rest being water, protein, carbohydrates and salts. It uses about 20% of the body's energy despite being only 2% of body weight. The cerebrum handles thinking, the cerebellum coordinates movement, and the brainstem controls vital functions.",
    keywords: ['brain', 'human', 'biology'] },

  // ---- HEALTH STUDY MATERIAL (ids 61-70) ----
  // Educational info only — NOT medical advice. Always recommend consulting a doctor.
  { id: 61, category: 'health', q: 'What is the cardiovascular system?',
    a: "The cardiovascular (circulatory) system consists of the heart, blood, and blood vessels (arteries, veins, capillaries). The heart pumps ~5 liters of blood per minute through ~100,000 km of vessels, delivering oxygen and nutrients to cells and removing waste. Arteries carry oxygenated blood away from the heart; veins return deoxygenated blood. Study tip: trace a red blood cell's journey — right atrium → right ventricle → lungs (picks up O₂) → left atrium → left ventricle → aorta → body → back to right atrium. Disclaimer: educational only; for health concerns consult a qualified doctor.",
    keywords: ['cardiovascular', 'heart', 'circulatory', 'blood', 'arteries', 'veins'] },
  { id: 62, category: 'health', q: 'How does the immune system work?',
    a: "The immune system has two main branches. **Innate immunity** (fast, non-specific): skin barrier, stomach acid, mucus, and white blood cells like neutrophils and macrophages that engulf invaders. **Adaptive immunity** (slow, specific, has memory): B-cells produce antibodies that tag specific pathogens, and T-cells destroy infected cells. After an infection, memory B and T cells remain, giving long-term immunity — this is how vaccines work (they train memory cells without causing illness). Study tip: contrast innate (fast, no memory) vs adaptive (slow, lifelong memory). Disclaimer: educational only; consult a doctor for medical concerns.",
    keywords: ['immune', 'immunity', 'antibodies', 'vaccine', 'white blood cells', 'pathogen'] },
  { id: 63, category: 'health', q: 'What is the respiratory system?',
    a: "The respiratory system exchanges oxygen and carbon dioxide between the body and the air. Pathway: nose/mouth → pharynx → larynx → trachea → bronchi → bronchioles → alveoli (~300 million tiny sacs). Gas exchange happens in the alveoli: O₂ diffuses into blood, CO₂ diffuses out. The diaphragm (a dome muscle below the lungs) contracts to inhale, relaxes to exhale. Adults breathe ~12-20 times per minute at rest. Study tip: surface area of alveoli if unfolded ≈ 70 m² (half a tennis court) — huge for efficient gas exchange. Disclaimer: educational only.",
    keywords: ['respiratory', 'lungs', 'breathing', 'alveoli', 'diaphragm', 'oxygen'] },
  { id: 64, category: 'health', q: 'What are the major food groups and why do they matter?',
    a: "The five major food groups: 1) **Carbohydrates** — main energy source (rice, bread, fruits). 2) **Proteins** — build and repair tissue, made of amino acids (meat, eggs, lentils). 3) **Fats** — long-term energy, hormone synthesis, cell membranes (nuts, oils, avocado). 4) **Vitamins & minerals** — micronutrients for enzymes, immunity, bones (vegetables, fruits, dairy). 5) **Water** — ~60% of body weight, essential for all reactions. A balanced plate: ½ vegetables/fruits, ¼ protein, ¼ whole grains, plus a small amount of healthy fat. Disclaimer: educational; for personalized diet advice consult a nutritionist or doctor.",
    keywords: ['food groups', 'nutrition', 'carbohydrates', 'protein', 'fat', 'vitamins', 'diet'] },
  { id: 65, category: 'health', q: 'What is the nervous system?',
    a: "The nervous system has two parts. **Central Nervous System (CNS)**: brain + spinal cord — processes information and makes decisions. **Peripheral Nervous System (PNS)**: all nerves outside the CNS — connects the body to the CNS. The PNS has two branches: somatic (voluntary movement) and autonomic (involuntary: heartbeat, digestion). The autonomic system splits into sympathetic ('fight or flight' — speeds things up) and parasympathetic ('rest and digest' — slows things down). Neurons communicate via electrical impulses (action potentials) and chemical signals (neurotransmitters). Study tip: sympathetic = stress, parasympathetic = peace. Disclaimer: educational only.",
    keywords: ['nervous system', 'neurons', 'brain', 'spinal cord', 'autonomic', 'sympathetic'] },
  { id: 66, category: 'health', q: 'What is diabetes?',
    a: "Diabetes is a condition where blood glucose (sugar) stays too high. **Type 1** (autoimmune): the pancreas produces little or no insulin; usually diagnosed in childhood; requires lifelong insulin injections. **Type 2** (metabolic): the body becomes resistant to insulin or doesn't make enough; linked to obesity, inactivity, age; often managed with diet, exercise, and medication. Insulin is a hormone that lets cells absorb glucose from blood. Symptoms include excessive thirst, frequent urination, fatigue, and blurred vision. Healthy diet, regular exercise, and weight management significantly reduce Type 2 risk. Disclaimer: educational only; consult a doctor for diagnosis and treatment.",
    keywords: ['diabetes', 'insulin', 'blood sugar', 'glucose', 'type 1', 'type 2'] },
  { id: 67, category: 'health', q: 'How does digestion work?',
    a: "Digestion breaks food into nutrients the body can absorb. Pathway: **Mouth** — chewing + amylase enzyme starts breaking down carbs. **Esophagus** — pushes food down via muscle waves (peristalsis). **Stomach** — acid (HCl) + pepsin enzyme break proteins; churns food into chyme. **Small intestine** — ~6m long; most absorption happens here via villi (tiny finger-like projections that increase surface area). Liver makes bile (emulsifies fat); pancreas releases enzymes for carbs, proteins, fats. **Large intestine (colon)** — absorbs water and electrolytes; houses gut bacteria that make vitamin K. Waste exits via the rectum. Total transit time: 24-72 hours. Disclaimer: educational only.",
    keywords: ['digestion', 'stomach', 'intestine', 'small intestine', 'absorption', 'enzymes'] },
  { id: 68, category: 'health', q: 'What is blood pressure and what do the numbers mean?',
    a: "Blood pressure is the force of blood against artery walls. It's measured as two numbers: **Systolic** (top, e.g. 120) — pressure when the heart beats; **Diastolic** (bottom, e.g. 80) — pressure when the heart rests between beats. Written as 120/80 mmHg. Ranges (general adult guidelines): Normal < 120/80; Elevated 120-129/<80; Stage 1 hypertension 130-139/80-89; Stage 2 ≥ 140/90. High blood pressure (hypertension) often has no symptoms but increases risk of heart disease and stroke. Healthy habits: low-sodium diet, regular exercise, healthy weight, limited alcohol, no smoking. Disclaimer: educational only; consult a doctor for diagnosis.",
    keywords: ['blood pressure', 'hypertension', 'systolic', 'diastolic', 'heart'] },
  { id: 69, category: 'health', q: 'Why is sleep important for health?',
    a: "Sleep is essential for physical and mental health. During sleep the body: repairs tissues and muscles; consolidates memories and learning (the brain 'replays' the day); clears waste from the brain via the glymphatic system; regulates hormones (including growth hormone and appetite hormones leptin/ghrelin); strengthens the immune system. Adults need 7-9 hours; teenagers 8-10; children 9-12; babies 12-17. Chronic sleep deprivation raises risk of obesity, diabetes, heart disease, depression, and weakens immunity. Sleep hygiene tips: consistent schedule, dark cool room, no screens 1 hour before bed, avoid caffeine after 2pm. Disclaimer: educational only.",
    keywords: ['sleep', 'rest', 'insomnia', 'sleep hygiene', 'health'] },
  { id: 70, category: 'health', q: 'What is mental health?',
    a: "Mental health includes our emotional, psychological, and social well-being — it affects how we think, feel, and act. Common conditions: **Anxiety disorders** (excessive worry, panic attacks), **Depression** (persistent sadness, loss of interest, fatigue), **Stress** (response to pressure, can be acute or chronic). Signs someone may need support: persistent low mood, withdrawal from friends, sleep/appetite changes, hopelessness, inability to concentrate. Self-care basics: regular sleep, exercise, social connection, limiting alcohol, mindfulness, talking to someone you trust. Professional help (therapy, counseling, sometimes medication) is effective and nothing to be ashamed of. If you or someone you know is in crisis, contact a helpline — in India: iCall 9152987821; in the US: 988. Disclaimer: educational; not a substitute for professional care.",
    keywords: ['mental health', 'anxiety', 'depression', 'stress', 'wellbeing', 'wellbeing'] },
]

// --- Category templates + fact bank + arithmetic generator (expand past 1000) --

const CATEGORY_TEMPLATES: Array<{ category: QA['category']; q: string; a: string; keywords: string[] }> = [
  { category: 'coding', q: 'What is a string in programming?', a: 'A string is a sequence of characters used to represent text. In JavaScript: `"hello"`. Common operations: concatenation (`"a" + "b"`), length (`.length`), substring, replace, split, and template literals (`` `Hi ${name}` ``).', keywords: ['string', 'text'] },
  { category: 'coding', q: 'What is a boolean?', a: 'A boolean is a data type with only two values: `true` or `false`. Used for flags, conditions, and comparisons. Example: `const isGameOver = false;` Booleans are the foundation of all `if` statements.', keywords: ['boolean', 'true', 'false'] },
  { category: 'coding', q: 'What is null vs undefined?', a: 'In JavaScript, `undefined` means a variable has been declared but not assigned a value. `null` is an intentional absence of value assigned by the developer. `typeof undefined` is "undefined"; `typeof null` is "object" (a famous JS quirk).', keywords: ['null', 'undefined', 'javascript'] },
  { category: 'coding', q: 'What is the DOM?', a: 'The DOM (Document Object Model) is a tree-like representation of an HTML page that JavaScript can manipulate. `document.getElementById("btn")` finds an element; `element.textContent = "Hi"` changes its text. Modern frameworks like React abstract the DOM away using a virtual DOM.', keywords: ['dom', 'html', 'javascript'] },
  { category: 'coding', q: 'What is an API?', a: 'An API (Application Programming Interface) is a set of rules for how software components communicate. Web APIs use HTTP: you send a request (GET, POST, etc.) to a URL and get back data (often JSON). Example: `fetch("/api/weather").then(r => r.json())`.', keywords: ['api', 'http', 'json'] },
  { category: 'coding', q: 'What is JSON?', a: 'JSON (JavaScript Object Notation) is a lightweight text format for storing and exchanging data. Syntax: `{"name": "Karan", "age": 25, "isCreator": true}`. Almost every modern API uses JSON. Parse with `JSON.parse(str)`, stringify with `JSON.stringify(obj)`.', keywords: ['json', 'data', 'format'] },
  { category: 'coding', q: 'What is async/await?', a: 'async/await is modern syntax for handling asynchronous operations. Mark a function `async`, then `await` promises inside it — code reads top-to-bottom like synchronous code. Example:\n```js\nasync function getData() {\n  const res = await fetch("/api");\n  const data = await res.json();\n  return data;\n}\n```', keywords: ['async', 'await', 'promise'] },
  { category: 'coding', q: 'What is a promise?', a: 'A Promise represents a value that may not be available yet but will resolve in the future. Three states: pending, fulfilled, rejected. Chain with `.then()`/`.catch()` or use async/await. Example: `fetch(url).then(r => r.json()).then(data => console.log(data))`.', keywords: ['promise', 'async', 'javascript'] },
  { category: 'coding', q: 'What is a hash table?', a: 'A hash table (or hash map / dictionary) stores key-value pairs and uses a hash function to compute an index for fast lookup. Average O(1) for insert, delete, search. JavaScript Objects and Maps, Python dicts, and Java HashMaps are all hash tables under the hood.', keywords: ['hash', 'dictionary', 'map'] },
  { category: 'coding', q: 'What is git?', a: 'Git is a version control system that tracks changes to code over time. Key commands: `git init` (start), `git add .` (stage), `git commit -m "msg"` (save), `git push` (upload to remote), `git pull` (download), `git branch` (manage branches).', keywords: ['git', 'version', 'control'] },
  { category: 'coding', q: 'What is the difference between frontend and backend?', a: 'Frontend = what users see (HTML, CSS, JavaScript, React, Vue). Backend = server-side logic (Node.js, Python, Java, databases, APIs). Full-stack developers work on both. This very page is frontend; the AI engine runs on the backend.', keywords: ['frontend', 'backend', 'fullstack'] },
  { category: 'math', q: 'What is the order of operations?', a: 'PEMDAS: Parentheses, Exponents, Multiplication/Division (left to right), Addition/Subtraction (left to right). Example: 2 + 3 × 4 = 14 (not 20), because multiplication happens before addition. (2 + 3) × 4 = 20.', keywords: ['pemdas', 'order', 'operations'] },
  { category: 'math', q: 'What is a fraction?', a: 'A fraction represents a part of a whole: numerator/denominator (e.g. 3/4 means 3 out of 4 equal parts). To add fractions, find a common denominator: 1/2 + 1/3 = 3/6 + 2/6 = 5/6. To multiply: multiply numerators, multiply denominators.', keywords: ['fraction', 'math', 'basic'] },
  { category: 'math', q: 'What is an exponent?', a: 'An exponent shows how many times a number is multiplied by itself: x^n means x multiplied n times. 2^3 = 2×2×2 = 8. Special cases: x^0 = 1, x^1 = x, x^-1 = 1/x. Negative exponents mean reciprocal: 2^-3 = 1/8.', keywords: ['exponent', 'power', 'math'] },
  { category: 'math', q: 'What is a logarithm?', a: 'A logarithm answers "to what power must the base be raised to get this number?". log_b(x) = y means b^y = x. Example: log_10(100) = 2 because 10^2 = 100. log_e (natural log, written ln) is common in calculus and growth/decay problems.', keywords: ['log', 'logarithm', 'math'] },
  { category: 'math', q: 'What is a matrix?', a: 'A matrix is a rectangular array of numbers arranged in rows and columns. Used in linear algebra, computer graphics, ML, and physics. Operations include addition, multiplication (special rules), transpose, and determinant (for square matrices).', keywords: ['matrix', 'linear algebra', 'array'] },
  { category: 'math', q: 'What is standard deviation?', a: 'Standard deviation measures how spread out numbers are from the mean. Low SD = data clustered near mean; high SD = data spread widely. Formula: sqrt(sum((x - mean)²) / n). It is the square root of variance.', keywords: ['standard deviation', 'statistics', 'spread'] },
  { category: 'math', q: 'What is probability?', a: 'Probability measures how likely an event is, from 0 (impossible) to 1 (certain). Formula: P(event) = favorable outcomes / total outcomes. Example: probability of rolling a 6 on a die = 1/6. Multiple independent events multiply: P(two 6s in a row) = 1/36.', keywords: ['probability', 'chance', 'statistics'] },
  { category: 'math', q: 'What is the golden ratio?', a: 'The golden ratio φ (phi) ≈ 1.6180339887... It appears when a line is divided so that the whole ÷ larger part = larger part ÷ smaller part. Found in art, architecture, nature (sunflowers, shells), and connected to Fibonacci numbers.', keywords: ['golden ratio', 'phi', 'nature'] },
  { category: 'cricket', q: 'What is a hat-trick in cricket?', a: 'A hat-trick is when a bowler takes 3 wickets on 3 consecutive deliveries. It can span across overs or even innings in Test cricket. Rare and celebrated — the bowler usually keeps the match ball as a souvenir.', keywords: ['hat-trick', 'wickets', 'bowler'] },
  { category: 'cricket', q: 'What is a yorker?', a: "A yorker is a delivery that lands right at the batter's feet (on the popping crease). Extremely hard to score off and a premier death-overs weapon. Lasith Malinga and Jasprit Bumrah are famous for their lethal yorkers.", keywords: ['yorker', 'bowling', 'delivery'] },
  { category: 'cricket', q: 'What is the powerplay in cricket?', a: 'Powerplay overs restrict fielding placements to encourage aggressive batting. In ODIs: overs 1-10 only 2 fielders outside the 30-yard circle, overs 11-40 four fielders, overs 41-50 five fielders. In T20s: 6 overs of powerplay with max 2 outside the circle.', keywords: ['powerplay', 'overs', 'rules'] },
  { category: 'cricket', q: 'What is a no-ball?', a: 'A no-ball is an illegal delivery — bowler oversteps the crease, bowls above waist height (full toss), or bowls dangerous short balls. Penalty: 1 free run + the next delivery is a "free hit" in limited-overs.', keywords: ['no-ball', 'free hit', 'rule'] },
  { category: 'cricket', q: 'What is the Indian Premier League?', a: "The IPL is the world's biggest T20 franchise cricket league, started in 2008. 10 city-based teams (Mumbai Indians, Chennai Super Kings, Royal Challengers Bengaluru, etc.) play each April-May. Players are auctioned, salaries are huge, and the league revolutionised cricket economics.", keywords: ['ipl', 'india', 'league'] },
  { category: 'cricket', q: 'Who is Sachin Tendulkar?', a: "Sachin Tendulkar is an Indian cricket legend, widely regarded as one of the greatest batters ever. He holds records for most Test runs (15,921), most ODI runs (18,426), most international centuries (100), and most international matches (664).", keywords: ['sachin', 'tendulkar', 'india', 'legend'] },
  { category: 'cricket', q: 'What is the strike rate?', a: 'Strike rate = (runs scored / balls faced) × 100. A T20 batter with a strike rate of 150 scores 1.5 runs per ball on average. Bowlers also have a strike rate: balls bowled per wicket taken. Higher is better for batters, lower for bowlers.', keywords: ['strike rate', 'stat', 'batting'] },
  { category: 'learn', q: 'How do I remember what I read?', a: 'Use the SQ3R method: Survey (skim), Question (turn headings into questions), Read actively, Recite (summarize in your own words), Review. Take notes in your own words, teach the concept to someone, revisit after 1 day, 1 week, 1 month (spaced repetition).', keywords: ['remember', 'reading', 'memory'] },
  { category: 'learn', q: 'What is the Feynman technique?', a: "Named after physicist Richard Feynman: (1) Pick a concept. (2) Explain it as if teaching a 12-year-old, in plain language. (3) Identify gaps where you got stuck or used jargon. (4) Go back, fill the gaps, simplify again. If you can't explain it simply, you don't understand it yet.", keywords: ['feynman', 'technique', 'learning'] },
  { category: 'realworld', q: 'How does GPS work?', a: "GPS uses 30+ satellites orbiting Earth. Your phone receives time signals from at least 4 satellites. By comparing the time each signal took to arrive, your phone triangulates your position — accurate to within 5-10 meters. GPS wouldn't work without Einstein's relativity corrections!", keywords: ['gps', 'satellite', 'technology'] },
  { category: 'realworld', q: 'Why is the sky blue?', a: 'Sunlight contains all colors. As it enters the atmosphere, gases and particles scatter shorter wavelengths (blue/violet) more than longer ones (red) — this is Rayleigh scattering. Our eyes are more sensitive to blue than violet, so we see a blue sky. At sunrise/sunset, light passes through more atmosphere, scattering away blue and leaving red/orange.', keywords: ['sky', 'blue', 'physics'] },
  { category: 'realworld', q: 'How do solar panels work?', a: 'Solar panels contain photovoltaic cells (usually silicon). When sunlight hits them, photons knock electrons loose from atoms, creating an electric current. An inverter converts the DC into AC that your home uses. Excess can be stored in batteries or sent to the grid.', keywords: ['solar', 'energy', 'renewable'] },
  { category: 'realworld', q: 'How do plants make food?', a: 'Plants make food via photosynthesis: chlorophyll in leaves captures sunlight, which powers a reaction converting CO₂ (from air) and H₂O (from roots) into glucose (food) and O₂ (released). Equation: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂.', keywords: ['photosynthesis', 'plants', 'biology'] },
  { category: 'ai', q: 'What is deep learning?', a: 'Deep learning is a subset of machine learning using neural networks with many layers (hence "deep"). Each layer learns increasingly abstract features — early layers detect edges, middle layers detect shapes, deep layers detect objects. Powering everything from ChatGPT to self-driving cars to medical diagnosis.', keywords: ['deep learning', 'neural', 'layers'] },
  { category: 'ai', q: 'What are hallucinations in AI?', a: 'Hallucinations = when an LLM confidently outputs false information. Cause: LLMs predict plausible-sounding text, not verified facts. Mitigation: cite sources, use RAG (retrieval-augmented generation), fact-check important outputs, and never trust LLMs blindly for medical/legal/financial advice.', keywords: ['hallucination', 'false', 'ai'] },
  { category: 'general', q: 'How deep is the ocean?', a: 'The deepest point is the Mariana Trench (Challenger Deep) at ~10,935 meters (about 11 km). Average ocean depth is ~3.7 km. Light only penetrates the top 200 m; below 1,000 m it is pitch black. Pressure at the bottom is over 1,000 atmospheres.', keywords: ['ocean', 'deep', 'mariana'] },
  { category: 'general', q: 'What causes the seasons?', a: "Seasons are caused by Earth's 23.5° axial tilt, NOT its distance from the Sun. When a hemisphere tilts toward the Sun, it gets more direct sunlight and longer days = summer. When it tilts away = winter. That's why seasons are opposite in the Northern and Southern hemispheres.", keywords: ['seasons', 'earth', 'tilt'] },
  { category: 'general', q: 'How many bones are in the human body?', a: 'Adults have 206 bones. Babies are born with ~270, many of which fuse as they grow. The smallest bone is the stapes (in the middle ear, ~3 mm). The largest is the femur (thigh bone). Bone is living tissue that constantly rebuilds itself.', keywords: ['bones', 'human', 'body'] },
]

function buildExpandedQA(): QA[] {
  const out: QA[] = [...CORE_QA]
  CATEGORY_TEMPLATES.forEach((t, i) => {
    out.push({ id: 100 + i, category: t.category, q: t.q, a: t.a, keywords: t.keywords })
  })

  const factBank: Record<QA['category'], string[]> = {
    ksk: [
      'KSK Games Studio has earned 509 likes from viewers who genuinely enjoy the content.',
      'The channel name KSK comes directly from its creator Karan.',
      'Karan handles every part of the channel — recording, editing, publishing — himself.',
      'KSK Games Studio currently has 50 subscribers and is on the path to 100.',
      'With 18,000+ total views, KSK Games Studio has reached viewers around the world.',
    ],
    coding: [
      'The first computer programmer was Ada Lovelace, who wrote an algorithm for the Analytical Engine in 1843.',
      'JavaScript was created by Brendan Eich in just 10 days in May 1995.',
      "Python is named after Monty Python's Flying Circus, not the snake.",
      'The Linux kernel has over 30 million lines of code contributed by thousands of developers.',
      'Git was created by Linus Torvalds in 2005 to manage Linux kernel development.',
      'The first computer bug was a real moth found in a Harvard Mark II relay in 1947.',
      'There are over 700 programming languages, but only ~25 are widely used.',
      'Stack Overflow has answered over 50 million programming questions since 2008.',
    ],
    math: [
      'Zero was invented independently by the ancient Mayans and Indian mathematicians around 1,500 years ago.',
      "The number e (Euler's number) ≈ 2.71828 is the base of natural logarithms and appears in growth/decay.",
      '1729 is the "Hardy-Ramanujan number" — the smallest number expressible as the sum of two cubes in two ways.',
      'A circle has 360 degrees because ancient Babylonians used base-60 numbering.',
      "Euler's identity e^(iπ) + 1 = 0 connects the five most important constants in math.",
      'There are exactly 5 Platonic solids: tetrahedron, cube, octahedron, dodecahedron, icosahedron.',
      'The Monty Hall problem shows switching doors doubles your chance of winning (from 1/3 to 2/3).',
      'A googol is 10^100; a googolplex is 10^(googol), larger than the number of atoms in the universe.',
    ],
    cricket: [
      'The longest cricket match ever was in 1939 between England and South Africa — it lasted 12 days and ended in a draw because the team had to catch their ship home.',
      'Sachin Tendulkar scored his first international century at age 17 against England in 1990.',
      'The Cricket World Cup was first held in 1975, won by the West Indies.',
      'Brian Lara holds the record for the highest individual Test innings: 400 not out.',
      'A cricket ball weighs between 155.9 and 163 grams and is made of cork wrapped in leather.',
      'The first-ever Test match was played between Australia and England in Melbourne in 1877.',
      "The highest team total in ODIs is England's 498/4 against the Netherlands in 2022.",
      'Muttiah Muralitharan holds the record for most wickets in Tests: 800.',
    ],
    learn: [
      'The brain creates about 700 new neurons per day in the hippocampus, the memory center.',
      'Sleeping within 3 hours of learning something new dramatically improves retention.',
      'Teaching someone else is one of the most effective ways to solidify your own understanding.',
      'Exercise increases BDNF, a protein that boosts memory and learning ability.',
      'It takes an average of 66 days to form a new habit, not 21 as commonly claimed.',
      'People who take notes by hand remember more than those who type — handwriting forces deeper processing.',
      'Curiosity releases dopamine, which enhances memory formation — interested learners remember more.',
    ],
    ai: [
      'The term "artificial intelligence" was coined by John McCarthy at the 1956 Dartmouth Conference.',
      'The first chatbot was ELIZA, created at MIT in 1966 to mimic a psychotherapist.',
      'Deep Blue became the first AI to beat a reigning chess world champion (Garry Kasparov) in 1997.',
      'AlphaGo beat Lee Sedol at Go in 2016 — a milestone experts thought was 10 years away.',
      'The ImageNet competition in 2012 sparked the deep learning revolution.',
      'The Turing Test, proposed by Alan Turing in 1950, judges if a machine can pass for human.',
      'The first neural network was the Perceptron, built in 1958 by Frank Rosenblatt.',
    ],
    realworld: [
      "A single bolt of lightning carries about 1 billion joules of energy and reaches 30,000°C — hotter than the Sun's surface.",
      'The human heart beats about 100,000 times per day, pumping 7,500 liters of blood.',
      'Honey never spoils — jars found in Egyptian tombs over 3,000 years old are still edible.',
      'Octopuses have three hearts, nine brains, and blue blood.',
      'Your smartphone has more computing power than all of NASA during the 1969 Moon landing.',
      'Bananas are slightly radioactive due to potassium-40, but you would need to eat 10 million in one sitting for it to matter.',
    ],
    general: [
      'A day on Venus is longer than a year on Venus — its rotation takes 243 Earth days, its orbit 225.',
      'Honeybees can recognise human faces.',
      'The Eiffel Tower can grow up to 15 cm taller in summer due to thermal expansion.',
      "A shrimp's heart is located in its head.",
      'There are more possible chess games than atoms in the observable universe.',
      'The shortest war in history was between Britain and Zanzibar in 1896 — it lasted 38 minutes.',
      'There are more stars in the universe than grains of sand on all Earth beaches.',
    ],
  }

  let nextId = 200
  const promptVariations = ['Tell me a fact about', 'Give me one interesting fact about', 'Share a fact about', 'What is one cool fact about']
  const topicMap: Record<QA['category'], string[]> = {
    ksk: ['KSK Games Studio', 'Karan the YouTuber'],
    coding: ['programming', 'coding history'],
    math: ['mathematics', 'numbers'],
    cricket: ['cricket', 'cricket history'],
    learn: ['learning', 'memory'],
    ai: ['artificial intelligence', 'AI history'],
    realworld: ['the real world', 'everyday science'],
    general: ['the world', 'fun facts'],
  }
  ;(Object.keys(factBank) as QA['category'][]).forEach((cat) => {
    promptVariations.forEach((pv) => {
      topicMap[cat].forEach((topic) => {
        factBank[cat].forEach((fact) => {
          out.push({ id: nextId++, category: cat, q: `${pv} ${topic}?`, a: fact, keywords: [topic.toLowerCase().split(' ')[0]] })
        })
      })
    })
  })

  const isPrime = (n: number): boolean => {
    if (n < 2) return false
    for (let i = 2; i * i <= n; i++) if (n % i === 0) return false
    return true
  }
  const getFactors = (n: number): number[] => {
    const f: number[] = []
    for (let i = 1; i <= n; i++) if (n % i === 0) f.push(i)
    return f
  }
  const arithmeticTemplates = [
    (a: number, b: number) => ({ q: `What is ${a} + ${b}?`, a: `${a} + ${b} = ${a + b}` }),
    (a: number, b: number) => ({ q: `What is ${a} plus ${b}?`, a: `${a} + ${b} = ${a + b}` }),
    (a: number, b: number) => ({ q: `What is ${a} × ${b}?`, a: `${a} × ${b} = ${a * b}` }),
    (a: number, b: number) => ({ q: `What is ${a} times ${b}?`, a: `${a} × ${b} = ${a * b}` }),
    (a: number, b: number) => ({ q: `What is ${a} - ${b}?`, a: `${a} - ${b} = ${a - b}` }),
    (a: number, b: number) => ({ q: `What is ${a} minus ${b}?`, a: `${a} - ${b} = ${a - b}` }),
    (a: number, b: number) => ({ q: `What is the square of ${a}?`, a: `${a}² = ${a * a}` }),
    (a: number, b: number) => ({ q: `Is ${a} a prime number?`, a: isPrime(a) ? `Yes, ${a} is prime — it is only divisible by 1 and itself.` : `No, ${a} is not prime. Its factors are: ${getFactors(a).join(', ')}.` }),
  ]
  for (let a = 2; a <= 25; a++) {
    for (let b = 2; b <= 15; b++) {
      arithmeticTemplates.forEach((tpl) => {
        const { q, a: ans } = tpl(a, b)
        out.push({ id: nextId++, category: 'math', q, a: ans, keywords: ['arithmetic'] })
      })
    }
  }

  const seen = new Set<string>()
  const deduped: QA[] = []
  for (const item of out) {
    const key = item.q.toLowerCase().trim()
    if (!seen.has(key)) {
      seen.add(key)
      deduped.push(item)
    }
  }
  return deduped
}

const QA_DATABASE = buildExpandedQA()

function findQuickAnswer(userMessage: string): QA | null {
  const raw = userMessage.trim()
  const msg = raw
    .toLowerCase().trim()
    .replace(/\bmultiplied by\b/g, '×').replace(/\btimes\b/g, '×')
    .replace(/\bplus\b/g, '+').replace(/\bminus\b/g, '-')
    .replace(/\bdivided by\b/g, '÷').replace(/\bsquared\b/g, '²')
  if (!msg) return null

  // ---- PERSONAL/CONVERSATIONAL BYPASS ----
  // If the user is talking about themselves ("my name is", "I like"), or
  // asking the AI to remember them ("do you remember", "what is my name"),
  // ALWAYS go to the LLM so it can use conversation memory. The Q&A database
  // is for facts, not for personal context — matching it here would return
  // wrong generic answers (e.g. "what is my name" used to match the AI Q&A).
  const personalPatterns = [
    /\bmy name\b/, /\bi am\b/, /\bi'm\b/, /\bim called\b/, /\bcall me\b/,
    /\bi like\b/, /\bi love\b/, /\bi prefer\b/, /\bi enjoy\b/, /\bi hate\b/,
    /\bi want\b/, /\bi need\b/, /\bi have\b/, /\bi know\b/, /\bi think\b/,
    /\bwhat is my name\b/, /\bwhat's my name\b/, /\bwhat do i\b/,
    /\bdo you (remember|know|recall)\b/, /\bwhat did i\b/, /\bwho am i\b/,
    /\bremember that\b/, /\bremember i\b/, /\bdon't (forget|you forget)\b/,
    /\bas i (said|mentioned|told you)\b/, /\bi told you\b/, /\bi said\b/,
    /\bas we (discussed|talked about)\b/, /\bearlier i\b/, /\bbefore i\b/,
    /\bmy (friend|brother|sister|dad|mom|teacher|class)\b/, /\bmy (favorite|favourite)\b/,
    /\bi'm from\b/, /\bi live in\b/, /\bi'm learning\b/, /\bi'm studying\b/,
  ]
  if (personalPatterns.some((re) => re.test(msg))) {
    return null  // skip Q&A — let the LLM handle this with memory
  }

  // Exact match — always trust
  for (const qa of QA_DATABASE) if (qa.q.toLowerCase() === msg) return qa

  let best: { qa: QA; score: number; overlap: number; hasKeyword: boolean; hasSubstring: boolean } | null = null
  for (const qa of QA_DATABASE) {
    const qLower = qa.q.toLowerCase()
    let score = 0
    let hasKeyword = false
    let hasSubstring = false
    if (qa.keywords) {
      for (const kw of qa.keywords) {
        // Skip overly generic 1-3 letter keywords — they cause false matches
        // (e.g. "ai" matches "rain", "what" matches everything).
        const k = kw.toLowerCase()
        if (k.length < 4 && !k.includes(' ')) continue
        if (msg.includes(k)) { score += 5; hasKeyword = true }
      }
    }
    const qWords = qLower.split(/\W+/).filter((w) => w.length > 2)  // ignore short words like "is", "a", "the"
    const mWords = msg.split(/\W+/).filter((w) => w.length > 2)
    const qSet = new Set(qWords)
    let common = 0
    for (const w of mWords) if (qSet.has(w)) { common++; score += 1 }
    const overlap = qWords.length > 0 ? common / qWords.length : 0
    if (qLower.includes(msg) || msg.includes(qLower)) { score += 3; hasSubstring = true }
    if (qa.id < 100) score += 2
    if (!best || score > best.score) best = { qa, score, overlap, hasKeyword, hasSubstring }
  }
  // STRICT GATE: require both keyword AND substring, OR a high overlap.
  // This is tighter than before — prevents "what is X" matching unrelated Q&As.
  if (best && best.score >= 6 && best.overlap >= 0.5 && (best.hasKeyword || best.hasSubstring)) {
    return best.qa
  }
  return null
}

// =============================================================================
//  API HELPERS (browser → server engine at /api/ksk)
// =============================================================================

async function callEngine(message: string, mode: Mode, history: Array<{ role: 'user' | 'assistant'; content: string }>) {
  const res = await fetch('/api/ksk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'chat', message, mode, history }),
  })
  const data = await res.json()
  if (!res.ok && !data.response) throw new Error(data.error || 'Request failed')
  return data.response as string
}

async function callImage(prompt: string) {
  const res = await fetch('/api/ksk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'image', prompt }),
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Image generation failed')
  return data.imageUrl as string
}

async function callVideo(prompt: string) {
  const res = await fetch('/api/ksk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'video', prompt }),
  })
  const data = await res.json()
  if (!res.ok) throw new Error(data.error || 'Video generation failed')
  return data.videoUrl as string
}

// Vision: user uploads an image OR a video, and asks a question about it.
// kind = 'image' sends image_url; kind = 'video' sends video_url.
async function callVision(message: string, media: string, kind: 'image' | 'video') {
  const res = await fetch('/api/ksk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'vision', message, image: media, mediaType: kind }),
  })
  const data = await res.json()
  if (!res.ok && !data.response) throw new Error(data.error || 'Analysis failed')
  return data.response as string
}

// =============================================================================
//  LIGHTWEIGHT MARKDOWN RENDERER
// =============================================================================

function FormattedText({ text }: { text: string }) {
  const parts = text.split(/(```[\s\S]*?```)/g)
  return (
    <>
      {parts.map((part, i) => {
        if (part.startsWith('```')) {
          const lines = part.replace(/```(\w+)?\n?/, '').replace(/```$/, '').split('\n')
          const langMatch = part.match(/```(\w+)/)
          const lang = langMatch?.[1] || 'code'
          return (
            <div key={i} className="my-2 rounded-lg bg-zinc-900 text-zinc-100 overflow-hidden border border-zinc-700">
              <div className="px-3 py-1 text-[10px] uppercase tracking-wide bg-zinc-800 text-zinc-400 font-mono">{lang}</div>
              <pre className="p-3 overflow-x-auto text-xs leading-relaxed font-mono"><code>{lines.join('\n')}</code></pre>
            </div>
          )
        }
        const html = part
          .replace(/`([^`]+)`/g, '<code class="px-1 py-0.5 rounded bg-zinc-200 dark:bg-zinc-700 text-xs font-mono">$1</code>')
          .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
        return <span key={i} dangerouslySetInnerHTML={{ __html: html }} />
      })}
    </>
  )
}

// =============================================================================
//  VOICE (Text-to-Speech) — uses the browser's free built-in speechSynthesis
//  No API calls, no rate limits, no credits used.
// =============================================================================

function speak(text: string) {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    alert("Your browser doesn't support text-to-speech. Try Chrome, Edge, or Safari.")
    return
  }
  const synth = window.speechSynthesis
  // Toggle: if already speaking this kind of text, stop
  if (synth.speaking) {
    synth.cancel()
    return
  }
  // Strip markdown-ish characters so they don't get read aloud
  const clean = text
    .replace(/```[\s\S]*?```/g, ' code block ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/[#>*_~]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  const utter = new SpeechSynthesisUtterance(clean)
  utter.rate = 1.0
  utter.pitch = 1.0
  utter.volume = 1.0
  synth.speak(utter)
}

// =============================================================================
//  CHAT BUBBLE
// =============================================================================

function ChatBubble({ message, onCopy }: { message: ChatMessage; onCopy: (t: string) => void }) {
  const isUser = message.role === 'user'
  return (
    <div className={cn('flex gap-3 group', isUser ? 'flex-row-reverse' : 'flex-row')}>
      {isUser ? (
        <Avatar className="h-9 w-9 shrink-0 border-2 border-background shadow-sm">
          <AvatarFallback className="bg-primary text-primary-foreground text-xs font-bold">
            <User className="h-4 w-4" />
          </AvatarFallback>
        </Avatar>
      ) : (
        <img src="/ksk-logo.png" alt="KSK AI" className="h-9 w-9 rounded-full object-cover border-2 border-background shadow-sm shrink-0" />
      )}
      <div className={cn('flex flex-col gap-1 max-w-[85%] sm:max-w-[75%]', isUser ? 'items-end' : 'items-start')}>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-foreground">{isUser ? 'You' : 'KSK AI'}</span>
          {message.mode && !isUser && (
            <Badge variant="secondary" className="text-[10px] py-0 h-4">{MODE_LABELS[message.mode]}</Badge>
          )}
        </div>
        <div
          className={cn(
            'rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap break-words',
            isUser ? 'bg-primary text-primary-foreground rounded-tr-sm' : 'bg-muted text-foreground rounded-tl-sm border',
          )}
        >
          {message.imageUrl ? (
            <div className="flex flex-col gap-2">
              <img src={message.imageUrl} alt="Generated by KSK AI" className="rounded-lg max-w-full h-auto border" />
              <a href={message.imageUrl} download={`ksk-ai-${Date.now()}.png`} className="text-xs underline opacity-80 hover:opacity-100">Download image</a>
            </div>
          ) : message.videoUrl ? (
            <div className="flex flex-col gap-2">
              <video src={message.videoUrl} controls className="rounded-lg max-w-full h-auto border" />
              <a href={message.videoUrl} download target="_blank" rel="noreferrer" className="text-xs underline opacity-80 hover:opacity-100">Open / download video</a>
            </div>
          ) : (
            <>
              {isUser && message.attachedImage && (
                <img src={message.attachedImage} alt="Uploaded by user" className="rounded-lg max-w-full max-h-64 h-auto border mb-2" />
              )}
              {isUser && message.attachedVideo && (
                <video src={message.attachedVideo} controls className="rounded-lg max-w-full max-h-64 h-auto border mb-2" />
              )}
              <FormattedText text={message.content} />
            </>
          )}
        </div>
        {!isUser && !message.imageUrl && !message.videoUrl && (
          <div className="flex items-center gap-3 opacity-0 group-hover:opacity-100 transition">
            <button onClick={() => onCopy(message.content)} className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1">
              <Copy className="h-3 w-3" /> Copy
            </button>
            <button onClick={() => speak(message.content)} className="text-[10px] text-muted-foreground hover:text-emerald-600 flex items-center gap-1" title="Read this reply aloud (click again to stop)">
              <Volume2 className="h-3 w-3" /> Listen
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// =============================================================================
//  MODE BUTTONS + STARTER PROMPTS
// =============================================================================

const MODE_BUTTONS: Array<{ mode: Mode; icon: any; label: string; hint: string }> = [
  { mode: 'chat', icon: MessageSquare, label: 'Chat', hint: 'General assistant' },
  { mode: 'image', icon: ImageIcon, label: 'Image', hint: 'Generate images' },
  { mode: 'video', icon: Film, label: 'Video', hint: 'Generate short videos' },
  { mode: 'code', icon: Code2, label: 'Code', hint: 'Programming help' },
  { mode: 'math', icon: Calculator, label: 'Math', hint: 'Solve & explain' },
  { mode: 'cricket', icon: Trophy, label: 'Cricket', hint: 'Stats & rules' },
  { mode: 'learn', icon: GraduationCap, label: 'Learn', hint: 'Real-world learning' },
  { mode: 'study', icon: BookOpen, label: 'Study', hint: 'Free flashcards' },
  { mode: 'game', icon: Gamepad2, label: 'Game', hint: 'Play text games' },
]

const STARTER_PROMPTS: Record<Mode, string[]> = {
  chat: ['Tell me about KSK Games Studio', 'How does the internet work?', 'What is artificial intelligence?', 'How can I support KSK?'],
  image: ['A cute cartoon cat playing cricket', 'A futuristic gaming controller with neon lights', 'A cozy YouTube gaming setup at night', 'A robot learning to paint'],
  video: ['A cinematic shot of a rocket launching at sunset', 'A cat playing with a glowing ball in slow motion', 'A futuristic city with flying cars at night', 'Waves crashing on a tropical beach at golden hour'],
  code: ['Write a function to check if a string is a palindrome', 'Explain how recursion works', 'Create a simple to-do list in JavaScript', 'What is the difference between let and const?'],
  math: ['What is the Pythagorean theorem?', 'Solve: 3x + 7 = 22', 'What is 15 times 7?', 'Explain percentages with an example'],
  cricket: ['What is a hat-trick in cricket?', 'Who is Sachin Tendulkar?', 'Explain the Duckworth-Lewis method', 'What is the powerplay rule?'],
  learn: ['Why is the sky blue?', 'How is math used in real life?', 'How do solar panels work?', 'Teach me the Feynman technique'],
  study: [],  // Study mode shows flashcards directly — no starter prompts needed
  game: ['Play trivia — ask me 5 questions', "Let's play 20 Questions (you think of something, I guess)", 'Play number guess (1-100)', 'Play word scramble'],
}

// =============================================================================
//  STUDY MODE — free flashcards (no API, runs 100% offline)
//  Tap a card to flip; use Prev/Next to move through the deck.
// =============================================================================

interface Flashcard { front: string; back: string }
interface FlashcardSet { id: string; name: string; emoji: string; description: string; cards: Flashcard[] }

const FLASHCARD_SETS: FlashcardSet[] = [
  {
    id: 'math',
    name: 'Math Basics',
    emoji: '🔢',
    description: 'Core math facts — multiplication, formulas, definitions',
    cards: [
      { front: 'What is the Pythagorean theorem?', back: 'a² + b² = c² — for a right triangle, the square of the hypotenuse equals the sum of the squares of the other two sides.' },
      { front: 'What is π (pi)?', back: 'The ratio of a circle\'s circumference to its diameter. Approximately 3.14159.' },
      { front: 'What is the area of a circle?', back: 'A = πr² (pi times radius squared)' },
      { front: 'What is the circumference of a circle?', back: 'C = 2πr (or πd, where d is diameter)' },
      { front: '7 × 8 = ?', back: '56' },
      { front: '9 × 9 = ?', back: '81' },
      { front: '12 × 12 = ?', back: '144' },
      { front: 'What is a prime number?', back: 'A whole number greater than 1 that can only be divided evenly by 1 and itself. Examples: 2, 3, 5, 7, 11, 13.' },
      { front: 'What is the quadratic formula?', back: 'x = (-b ± √(b² - 4ac)) / 2a — solves ax² + bx + c = 0' },
      { front: 'What is the order of operations?', back: 'PEMDAS: Parentheses → Exponents → Multiplication/Division → Addition/Subtraction.' },
      { front: 'What is 15% of 200?', back: '30. (10% = 20, 5% = 10, total = 30)' },
      { front: 'What is a factorial (n!)?', back: 'The product of all positive integers up to n. Example: 5! = 5×4×3×2×1 = 120. By convention, 0! = 1.' },
    ],
  },
  {
    id: 'science',
    name: 'Science',
    emoji: '🔬',
    description: 'Biology, chemistry, physics fundamentals',
    cards: [
      { front: 'What is the powerhouse of the cell?', back: 'The mitochondria. It produces ATP (energy) through cellular respiration.' },
      { front: 'What is the chemical formula for water?', back: 'H₂O — two hydrogen atoms bonded to one oxygen atom.' },
      { front: 'What is Newton\'s first law?', back: 'An object at rest stays at rest, and an object in motion stays in motion at constant velocity, unless acted on by an external force. (Law of inertia.)' },
      { front: 'What is photosynthesis?', back: 'The process by which plants convert sunlight, CO₂, and water into glucose and oxygen. Equation: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂.' },
      { front: 'What is the speed of light?', back: 'Approximately 299,792,458 m/s (about 300,000 km/s) in a vacuum. Nothing travels faster.' },
      { front: 'What are the three states of matter?', back: 'Solid, liquid, gas. (Plasma is sometimes called the fourth state.)' },
      { front: 'What is DNA?', back: 'Deoxyribonucleic acid — the molecule that carries genetic instructions. Structure: a double helix, discovered by Watson & Crick (1953).' },
      { front: 'What is the periodic table?', back: 'A table arranging all known chemical elements by atomic number. Hydrogen (H, #1) is the lightest; Oganesson (Og, #118) is the heaviest known.' },
      { front: 'What is gravity?', back: 'A force that attracts two bodies toward each other. On Earth, it accelerates objects at ~9.8 m/s².' },
      { front: 'What is the pH scale?', back: 'A 0-14 scale measuring acidity: 0-6 = acid, 7 = neutral (water), 8-14 = base/alkaline.' },
    ],
  },
  {
    id: 'english',
    name: 'English',
    emoji: '📖',
    description: 'Grammar, vocabulary, literary devices',
    cards: [
      { front: 'What is a noun?', back: 'A word that names a person, place, thing, or idea. Examples: teacher, Mumbai, book, freedom.' },
      { front: 'What is a verb?', back: 'An action word — describes what the subject does. Examples: run, think, is, become.' },
      { front: 'What is an adjective?', back: 'A word that describes a noun. Examples: tall, blue, intelligent, several.' },
      { front: 'What is a metaphor?', back: 'A figure of speech that directly compares two unrelated things WITHOUT "like" or "as". Example: "Time is a thief."' },
      { front: 'What is a simile?', back: 'A comparison using "like" or "as". Example: "She runs like the wind."' },
      { front: 'What is the difference between "their", "there", and "they\'re"?', back: 'their = possessive (their book); there = location (over there); they\'re = "they are" (they\'re happy).' },
      { front: 'What is alliteration?', back: 'The repetition of the same consonant sound at the start of nearby words. Example: "Peter Piper picked a peck of pickled peppers."' },
      { front: 'What is a synonym?', back: 'A word with the same or similar meaning as another word. Example: "happy" and "joyful".' },
      { front: 'What is the past tense of "go"?', back: 'went. (Past participle: gone. "I go" → "I went" → "I have gone".)' },
      { front: 'What is onomatopoeia?', back: 'A word that imitates the sound it represents. Examples: buzz, hiss, meow, splash, bang.' },
    ],
  },
  {
    id: 'history',
    name: 'History',
    emoji: '🏛️',
    description: 'World history key dates and figures',
    cards: [
      { front: 'When did World War II end?', back: 'September 2, 1945 — Japan formally surrendered aboard the USS Missouri.' },
      { front: 'Who was the first Prime Minister of India?', back: 'Jawaharlal Nehru (served 1947-1964).' },
      { front: 'When did India gain independence?', back: 'August 15, 1947 — from British colonial rule.' },
      { front: 'Who wrote the Indian national anthem?', back: 'Rabindranath Tagore — "Jana Gana Mana", adopted in 1950.' },
      { front: 'When did the Berlin Wall fall?', back: 'November 9, 1989 — symbolically ending the Cold War division of Europe.' },
      { front: 'Who was the first President of the United States?', back: 'George Washington (served 1789-1797).' },
      { front: 'When did humans first land on the Moon?', back: 'July 20, 1969 — Apollo 11, Neil Armstrong and Buzz Aldrin. "That\'s one small step for man..."' },
      { front: 'When did the Maurya Empire rule India?', back: '322-185 BCE. Founded by Chandragupta Maurya; its greatest ruler was Ashoka the Great.' },
      { front: 'Who founded the Mughal Empire in India?', back: 'Babur, in 1526, after winning the First Battle of Panipat.' },
      { front: 'When was the United Nations founded?', back: 'October 24, 1945 — after World War II, to maintain international peace.' },
    ],
  },
  {
    id: 'general',
    name: 'General Knowledge',
    emoji: '🌍',
    description: 'Capitals, currencies, geography, mixed facts',
    cards: [
      { front: 'What is the capital of India?', back: 'New Delhi.' },
      { front: 'What is the capital of Japan?', back: 'Tokyo.' },
      { front: 'What is the largest country by area?', back: 'Russia — about 17.1 million km², spanning 11 time zones.' },
      { front: 'What is the longest river in the world?', back: 'The Nile (about 6,650 km). Some studies argue the Amazon is slightly longer, but traditionally the Nile holds the title.' },
      { front: 'What is the smallest country in the world?', back: 'Vatican City — about 0.44 km², an independent city-state enclaved within Rome.' },
      { front: 'How many continents are there?', back: '7: Africa, Antarctica, Asia, Australia/Oceania, Europe, North America, South America.' },
      { front: 'What is the currency of the United States?', back: 'The US Dollar (USD, symbol $).' },
      { front: 'What is the currency of India?', back: 'The Indian Rupee (INR, symbol ₹).' },
      { front: 'What is the tallest mountain in the world?', back: 'Mount Everest — 8,848.86 m (29,031.7 ft), in the Himalayas on the Nepal-China border.' },
      { front: 'What language has the most native speakers?', back: 'Mandarin Chinese — about 920 million native speakers, more than any other language.' },
    ],
  },
  {
    id: 'cricket',
    name: 'Cricket',
    emoji: '🏏',
    description: 'Cricket rules, legends, records',
    cards: [
      { front: 'What is a hat-trick in cricket?', back: 'When a bowler takes three wickets on three consecutive deliveries (in the same match).' },
      { front: 'Who holds the record for most ODI runs?', back: 'Sachin Tendulkar — 18,426 runs in 463 ODIs.' },
      { front: 'How many players are on a cricket team?', back: '11. (Plus a 12th man who can field but not bat or bowl.)' },
      { front: 'What does LBW stand for?', back: 'Leg Before Wicket — a mode of dismissal when the ball hits the batter\'s leg in line with the stumps and would have hit them.' },
      { front: 'What is the Duckworth-Lewis method?', back: 'A mathematical formula used to recalculate target scores in rain-affected limited-overs matches.' },
      { front: 'Who has the most Test wickets?', back: 'Muttiah Muralitharan (Sri Lanka) — 800 wickets in 133 Tests.' },
      { front: 'What is a "duck" in cricket?', back: 'When a batter is dismissed for zero runs. A "golden duck" is out on the first ball faced.' },
      { front: 'What are the three main formats of cricket?', back: 'Test (5 days, unlimited overs per innings), ODI (50 overs per side), T20 (20 overs per side).' },
      { front: 'Who won the first Cricket World Cup (1975)?', back: 'West Indies — beat Australia by 17 runs in the final at Lord\'s.' },
      { front: 'What is the powerplay rule?', back: 'A fielding restriction period where only a limited number of fielders can be outside the 30-yard circle. In ODIs: overs 1-10 (only 2 outside), 11-40 (4 outside), 41-50 (5 outside).' },
    ],
  },
]

function FlashcardStudy() {
  const [setId, setSetId] = useState<string>('math')
  const [idx, setIdx] = useState(0)
  const [flipped, setFlipped] = useState(false)

  const set = FLASHCARD_SETS.find((s) => s.id === setId) || FLASHCARD_SETS[0]
  const card = set.cards[idx]

  const goNext = () => { setFlipped(false); setIdx((i) => (i + 1) % set.cards.length) }
  const goPrev = () => { setFlipped(false); setIdx((i) => (i - 1 + set.cards.length) % set.cards.length) }
  const pickSet = (newId: string) => { setSetId(newId); setIdx(0); setFlipped(false) }

  return (
    <div className="space-y-4">
      {/* Set picker */}
      <div>
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 flex items-center gap-1.5">
          <BookOpen className="h-3.5 w-3.5" /> Choose a flashcard set
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {FLASHCARD_SETS.map((s) => (
            <button
              key={s.id}
              onClick={() => pickSet(s.id)}
              className={cn(
                'text-left px-3 py-2 rounded-lg border transition',
                s.id === setId
                  ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-500/40'
                  : 'bg-card hover:bg-muted',
              )}
            >
              <div className="text-lg">{s.emoji}</div>
              <div className="text-xs font-bold mt-0.5">{s.name}</div>
              <div className="text-[10px] text-muted-foreground">{s.cards.length} cards</div>
            </button>
          ))}
        </div>
      </div>

      {/* Flashcard */}
      <div
        onClick={() => setFlipped((f) => !f)}
        className="cursor-pointer rounded-2xl border-2 bg-card hover:shadow-md transition min-h-[220px] flex flex-col items-center justify-center p-6 text-center select-none"
        title="Click to flip"
      >
        <div className="text-[10px] uppercase tracking-widest text-emerald-600 font-bold mb-2">
          {flipped ? 'Answer' : 'Question'} · Card {idx + 1} of {set.cards.length}
        </div>
        <div className="text-base sm:text-lg font-medium leading-relaxed">
          {flipped ? card.back : card.front}
        </div>
        <div className="text-[10px] text-muted-foreground mt-4">
          {flipped ? '← click to see question again' : 'click to reveal answer →'}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between gap-2">
        <Button onClick={goPrev} variant="outline" size="sm">← Prev</Button>
        <span className="text-xs text-muted-foreground">{set.emoji} {set.name}</span>
        <Button onClick={goNext} size="sm" className="bg-emerald-600 hover:bg-emerald-700">Next →</Button>
      </div>
    </div>
  )
}

// =============================================================================
//  MAIN PAGE
// =============================================================================

export default function Home() {
  const [mode, setMode] = useState<Mode>('chat')
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    // Restore saved chat history from localStorage on first load
    if (typeof window === 'undefined') return []
    try {
      const saved = window.localStorage.getItem('ksk-chat-history')
      if (saved) {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed) && parsed.length > 0) return parsed as ChatMessage[]
      }
    } catch { /* ignore corrupt storage */ }
    return [
      {
        role: 'assistant',
        content: "Hey there! I'm KSK AI — your friendly assistant built for the KSK Games Studio community (Karan's channel @kskgamesstudio). I can chat, generate images and short videos, write code, solve math, talk cricket, and teach real-world concepts. Pick a mode above or just type your question below. What would you like to do?\n\n⚠️ Please note: KSK AI can make mistakes. Always double-check important facts, code, math, or health/safety info with a trusted source.",
        timestamp: Date.now(),
        mode: 'chat',
      },
    ]
  })
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [imageLoading, setImageLoading] = useState(false)
  const [videoLoading, setVideoLoading] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [showKskInfo, setShowKskInfo] = useState(false)
  const [theme, setTheme] = useState<'light' | 'dark'>('light')

  // Persist chat history to localStorage whenever it changes (so a refresh
  // doesn't lose the conversation). We trim to last 50 messages to stay under
  // the ~5MB localStorage limit.
  useEffect(() => {
    if (typeof window === 'undefined') return
    try {
      const trimmed = messages.slice(-50)
      window.localStorage.setItem('ksk-chat-history', JSON.stringify(trimmed))
    } catch { /* storage full or disabled — ignore */ }
  }, [messages])

  // ---- Live YouTube stats ----
  // Fetch real subscriber/view counts from the AI engine (POST /api/ksk with
  // type=youtube-stats). Falls back to hardcoded values if fetch fails.
  const [ytStats, setYtStats] = useState<{ subscribers?: string; views?: string; videos?: string } | null>(null)
  useEffect(() => {
    let cancelled = false
    fetch('/api/ksk', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'youtube-stats' }),
    })
      .then((r) => r.ok ? r.json() : null)
      .then((data) => {
        if (!cancelled && data && (data.subscribers || data.views)) {
          setYtStats({ subscribers: data.subscribers, views: data.views, videos: data.videos })
        }
      })
      .catch(() => { /* silent fallback to hardcoded values */ })
    return () => { cancelled = true }
  }, [])

  // On first mount, read saved theme (or system preference) and apply it
  useEffect(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('ksk-theme') : null
    const prefersDark = typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches
    const initial: 'light' | 'dark' = saved === 'dark' || saved === 'light' ? saved : (prefersDark ? 'dark' : 'light')
    setTheme(initial)
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark', initial === 'dark')
    }
  }, [])

  const toggleTheme = () => {
    const next: 'light' | 'dark' = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    if (typeof document !== 'undefined') {
      document.documentElement.classList.toggle('dark', next === 'dark')
    }
    if (typeof window !== 'undefined') {
      localStorage.setItem('ksk-theme', next)
    }
  }
  const [attachedImage, setAttachedImage] = useState<string>('')  // data URL of pending image upload
  const [attachedVideo, setAttachedVideo] = useState<string>('')  // data URL of pending video upload
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight
  }, [messages, loading, imageLoading, videoLoading])

  // Convert a File to a data URL for preview + upload
  const readFileAsDataUrl = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(String(reader.result || ''))
      reader.onerror = reject
      reader.readAsDataURL(file)
    })

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const isImage = file.type.startsWith('image/')
    const isVideo = file.type.startsWith('video/')
    if (!isImage && !isVideo) {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'Please choose an image (PNG, JPG, GIF, WEBP) or a video (MP4, WEBM, MOV).', timestamp: Date.now(), mode }])
      e.target.value = ''
      return
    }
    // Image max 8 MB, video max 25 MB (videos are bigger)
    const maxBytes = isImage ? 8 * 1024 * 1024 : 25 * 1024 * 1024
    const maxLabel = isImage ? '8 MB' : '25 MB'
    if (file.size > maxBytes) {
      setMessages((prev) => [...prev, { role: 'assistant', content: `That ${isImage ? 'image' : 'video'} is larger than ${maxLabel}. Please pick a smaller file so the upload stays fast.`, timestamp: Date.now(), mode }])
      e.target.value = ''
      return
    }
    try {
      const dataUrl = await readFileAsDataUrl(file)
      if (isImage) {
        setAttachedImage(dataUrl)
        setAttachedVideo('')
      } else {
        setAttachedVideo(dataUrl)
        setAttachedImage('')
      }
    } catch {
      setMessages((prev) => [...prev, { role: 'assistant', content: 'I could not read that file. Please try a different one.', timestamp: Date.now(), mode }])
    }
    e.target.value = ''
  }

  const handleSend = useCallback(async () => {
    const text = input.trim()
    const hasImage = !!attachedImage
    const hasVideo = !!attachedVideo
    if ((!text && !hasImage && !hasVideo) || loading) return

    // If user only uploaded a file with no text, give it a default prompt
    const effectiveText = text || (hasImage ? 'Describe this image in detail.' : hasVideo ? 'Describe what is happening in this video.' : '')

    const userMsg: ChatMessage = {
      role: 'user',
      content: effectiveText,
      timestamp: Date.now(),
      mode,
      ...(hasImage ? { attachedImage } : {}),
      ...(hasVideo ? { attachedVideo } : {}),
    }
    const newHistory = [...messages, userMsg]
    setMessages(newHistory)
    setInput('')
    const pendingImage = attachedImage
    const pendingVideo = attachedVideo
    setAttachedImage('')
    setAttachedVideo('')
    setLoading(true)

    try {
      // 0. SAFETY FIRST — if the user is in danger/crisis, respond immediately with helplines.
      // This runs BEFORE the profanity filter so we never refuse a cry for help.
      if (text && checkSafety(text)) {
        setMessages((prev) => [...prev, { role: 'assistant', content: SAFETY_RESPONSE, timestamp: Date.now(), mode }])
        return
      }

      // 0b. VIOLENCE REFUSAL — "how to kill [person]", "murder", etc. → firm no.
      // Runs before the LLM so the model never sees the request.
      if (text && checkViolence(text)) {
        setMessages((prev) => [...prev, { role: 'assistant', content: VIOLENCE_RESPONSE, timestamp: Date.now(), mode }])
        return
      }

      // 1. Client-side protection (instant refusal) — only on text portion
      if (text) {
        const blocked = checkProtection(text)
        if (blocked) {
          setMessages((prev) => [...prev, { role: 'assistant', content: blocked, timestamp: Date.now(), mode }])
          return
        }
      }

      // 2. File attached → vision flow (image or video), regardless of mode
      if (hasImage && pendingImage) {
        const response = await callVision(effectiveText, pendingImage, 'image')
        setMessages((prev) => [...prev, { role: 'assistant', content: response, timestamp: Date.now(), mode }])
        return
      }
      if (hasVideo && pendingVideo) {
        const response = await callVision(effectiveText, pendingVideo, 'video')
        setMessages((prev) => [...prev, { role: 'assistant', content: response, timestamp: Date.now(), mode }])
        return
      }

      // 2.5. Pure-arithmetic evaluator — runs BEFORE the LLM because LLMs
      // hallucinate arithmetic on big numbers. Guarantees correct results
      // for expressions like "3-(7)+90(8)x(78)" or "15 times 7".
      if (text) {
        const math = tryArithmetic(text)
        if (math) {
          setMessages((prev) => [...prev, { role: 'assistant', content: math, timestamp: Date.now(), mode }])
          return
        }
      }

      // 3. Try instant Q&A from the 1000+ database
      const quick = findQuickAnswer(effectiveText)
      if (quick && mode !== 'image' && mode !== 'video') {
        setMessages((prev) => [...prev, { role: 'assistant', content: quick.a, timestamp: Date.now(), mode }])
        return
      }

      if (mode === 'image') {
        // Image flow: refine prompt → generate image
        setImageLoading(true)
        const refined = await callEngine(effectiveText, 'image', newHistory.map((m) => ({ role: m.role, content: m.content })))
        const promptMatch = refined.match(/PROMPT:\s*(.+)/i)
        const finalPrompt = promptMatch ? promptMatch[1].trim() : effectiveText

        setMessages((prev) => [...prev, { role: 'assistant', content: `Generating an image for: "${finalPrompt}"...`, timestamp: Date.now(), mode }])
        const imageUrl = await callImage(finalPrompt)
        setImageLoading(false)
        setMessages((prev) => [...prev, { role: 'assistant', content: 'Here is your image:', timestamp: Date.now(), mode, imageUrl }])
      } else if (mode === 'video') {
        // Video flow: refine prompt → generate video (can take up to ~3 min)
        setVideoLoading(true)
        const refined = await callEngine(effectiveText, 'video', newHistory.map((m) => ({ role: m.role, content: m.content })))
        const promptMatch = refined.match(/PROMPT:\s*(.+)/i)
        const finalPrompt = promptMatch ? promptMatch[1].trim() : effectiveText

        setMessages((prev) => [...prev, { role: 'assistant', content: `Rendering a video for: "${finalPrompt}" — this can take 30-90 seconds. Hang tight...`, timestamp: Date.now(), mode }])
        const videoUrl = await callVideo(finalPrompt)
        setVideoLoading(false)
        setMessages((prev) => [...prev, { role: 'assistant', content: 'Here is your video:', timestamp: Date.now(), mode, videoUrl }])
      } else {
        // Chat flow: call the engine
        const response = await callEngine(effectiveText, mode, newHistory.map((m) => ({ role: m.role, content: m.content })))
        setMessages((prev) => [...prev, { role: 'assistant', content: response, timestamp: Date.now(), mode }])
      }
    } catch (e: any) {
      setMessages((prev) => [...prev, { role: 'assistant', content: `Something went wrong: ${e?.message || 'Unknown error'}. Please try again.`, timestamp: Date.now(), mode }])
    } finally {
      setLoading(false)
      setImageLoading(false)
      setVideoLoading(false)
    }
  }, [input, loading, mode, messages, attachedImage, attachedVideo])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
  }
  const handleCopy = (text: string) => navigator.clipboard.writeText(text)
  const handleClear = () => {
    if (typeof window !== 'undefined') window.localStorage.removeItem('ksk-chat-history')
    setMessages([{ role: 'assistant', content: 'Fresh start! What would you like to talk about?', timestamp: Date.now(), mode }])
  }
  const pickStarterPrompt = (prompt: string) => { setInput(prompt); inputRef.current?.focus() }

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Mobile sidebar toggle */}
      <button onClick={() => setSidebarOpen(!sidebarOpen)} className="fixed top-4 left-4 z-50 md:hidden bg-background border rounded-lg p-2 shadow-sm" aria-label="Toggle sidebar">
        {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Sidebar */}
      <aside className={cn('fixed md:static inset-y-0 left-0 z-40 w-72 bg-card border-r flex flex-col transition-transform', sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0')}>
        {/* Brand */}
        <div className="p-4 border-b shrink-0">
          <div className="flex items-center gap-3">
            <img src="/ksk-logo.png" alt="KSK Games Studio" className="h-11 w-11 rounded-xl object-cover shadow-md" />
            <div>
              <h1 className="text-base font-bold leading-tight">KSK AI</h1>
              <p className="text-[11px] text-muted-foreground leading-tight">By Karan &middot; kskgamesstudio</p>
            </div>
          </div>
        </div>

        {/* Scrollable middle: New chat + Modes + KSK info card */}
        <div className="flex-1 overflow-y-auto ksk-scroll">
          {/* New chat */}
          <div className="p-3">
            <Button onClick={handleClear} variant="outline" className="w-full justify-start gap-2">
              <RefreshCw className="h-4 w-4" /> New chat
            </Button>
          </div>

          {/* Mode buttons */}
          <div className="px-3 pb-3">
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide px-2 mb-2">Modes</p>
            <div className="space-y-1">
              {MODE_BUTTONS.map((b) => {
                const Icon = b.icon
                const active = mode === b.mode
                return (
                  <button
                    key={b.mode}
                    onClick={() => { setMode(b.mode); setSidebarOpen(false) }}
                    className={cn(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition group',
                      active ? 'bg-gradient-to-r from-emerald-500/15 to-teal-500/15 text-foreground border border-emerald-500/30' : 'hover:bg-muted text-muted-foreground hover:text-foreground',
                    )}
                  >
                    <Icon className={cn('h-4 w-4', active ? 'text-emerald-600' : '')} />
                    <span className="font-medium">{b.label}</span>
                    <span className="text-[10px] text-muted-foreground ml-auto hidden sm:inline">{b.hint}</span>
                  </button>
                )
              })}
            </div>
          </div>

          <Separator />

          {/* KSK info card */}
          <div className="p-3">
            <button
              onClick={() => setShowKskInfo(!showKskInfo)}
              className="w-full text-left rounded-lg border bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 p-3 hover:shadow-sm transition"
            >
              <div className="flex items-center gap-2 mb-2">
                <Youtube className="h-4 w-4 text-red-600" />
                <span className="text-xs font-bold">KSK Games Studio</span>
              </div>
              <div className="grid grid-cols-3 gap-1 text-center">
                <div>
                  <div className="text-sm font-bold text-foreground flex items-center justify-center gap-1">
                    {ytStats?.subscribers || KSK_INFO.stats.subscribers}
                    {ytStats?.subscribers && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" title="Live" />}
                  </div>
                  <div className="text-[9px] text-muted-foreground uppercase">Subs</div>
                </div>
                <div>
                  <div className="text-sm font-bold text-foreground flex items-center justify-center gap-1">
                    {ytStats?.views || KSK_INFO.stats.views}
                    {ytStats?.views && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" title="Live" />}
                  </div>
                  <div className="text-[9px] text-muted-foreground uppercase">Views</div>
                </div>
                <div>
                  <div className="text-sm font-bold text-foreground flex items-center justify-center gap-1">
                    {ytStats?.videos || KSK_INFO.stats.likes}
                    {ytStats?.videos && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" title="Live" />}
                  </div>
                  <div className="text-[9px] text-muted-foreground uppercase">{ytStats?.videos ? 'Videos' : 'Likes'}</div>
                </div>
              </div>
              <div className="text-[9px] text-muted-foreground text-center mt-1.5 flex items-center justify-center gap-1">
                {ytStats
                  ? <><span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> Live from YouTube</>
                  : <><Youtube className="h-2.5 w-2.5" /> Loading live stats…</>}
              </div>
              {showKskInfo && <p className="text-[11px] text-muted-foreground mt-2 leading-relaxed">{KSK_INFO.description}</p>}
              <p className="text-[10px] text-emerald-700 dark:text-emerald-400 mt-2 flex items-center gap-1">
                {showKskInfo ? 'Hide' : 'Show'} details <ChevronRight className="h-3 w-3" />
              </p>
            </button>
          </div>

          {/* Trusted links: KSK YouTube + Casa Theroyal rental */}
          <div className="px-1 pb-1 space-y-1.5">
            <a
              href={KSK_INFO.youtubeUrl}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-xs px-2.5 py-2 rounded-lg border bg-card hover:bg-muted hover:border-red-500/40 transition"
            >
              <Youtube className="h-3.5 w-3.5 text-red-600 shrink-0" />
              <span className="font-medium">KSK on YouTube</span>
              <ChevronRight className="h-3 w-3 ml-auto text-muted-foreground" />
            </a>
            {KSK_INFO.trustedProjects.map((p) => (
              <a
                key={p.url}
                href={p.url}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 text-xs px-2.5 py-2 rounded-lg border bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 hover:shadow-sm transition"
              >
                <Shield className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                <div className="min-w-0">
                  <div className="font-medium truncate">{p.name}</div>
                  <div className="text-[9px] text-muted-foreground truncate">{p.kind}</div>
                </div>
                <ChevronRight className="h-3 w-3 ml-auto text-muted-foreground shrink-0" />
              </a>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 border-t shrink-0">
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
            <Shield className="h-3.5 w-3.5 text-emerald-600" />
            <span>Protecting Karan & KSK community</span>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2 flex items-center gap-1">
            <span className="text-amber-600">⚠</span> KSK AI can make mistakes — double-check important info.
          </p>
          <p className="text-[10px] text-muted-foreground mt-1.5">{QA_DATABASE.length.toLocaleString()}+ Q&A in knowledge base</p>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && <div className="fixed inset-0 bg-black/40 z-30 md:hidden" onClick={() => setSidebarOpen(false)} />}

      {/* Main chat area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center justify-between px-4 md:px-6 py-3">
            <div className="flex items-center gap-3 md:ml-0 ml-12">
              <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                {(() => { const Icon = MODE_BUTTONS.find((b) => b.mode === mode)?.icon || MessageSquare; return <Icon className="h-4 w-4 text-white" /> })()}
              </div>
              <div>
                <h2 className="text-sm font-bold leading-tight">KSK AI &middot; {MODE_LABELS[mode]} Mode</h2>
                <p className="text-[11px] text-muted-foreground leading-tight">{MODE_BUTTONS.find((b) => b.mode === mode)?.hint}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={toggleTheme}
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
                title={theme === 'dark' ? 'Switch to light (white) background' : 'Switch to dark (black) background'}
              >
                {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </Button>
              <Button onClick={handleClear} variant="ghost" size="icon" className="h-8 w-8" aria-label="Clear chat">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Messages — native scrollable div so ref works for auto-scroll + visible scrollbar */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto ksk-scroll scroll-smooth">
          <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
            {messages.map((m, i) => <ChatBubble key={i} message={m} onCopy={handleCopy} />)}

            {loading && !imageLoading && !videoLoading && (
              <div className="flex gap-3">
                <img src="/ksk-logo.png" alt="KSK AI" className="h-9 w-9 rounded-full object-cover border-2 border-background shrink-0" />
                <div className="flex items-center gap-1.5 bg-muted rounded-2xl rounded-tl-sm px-4 py-3 border">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:-0.3s]" />
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-bounce [animation-delay:-0.15s]" />
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-bounce" />
                </div>
              </div>
            )}

            {imageLoading && (
              <div className="flex gap-3">
                <img src="/ksk-logo.png" alt="KSK AI" className="h-9 w-9 rounded-full object-cover border-2 border-background shrink-0" />
                <div className="flex items-center gap-2 bg-muted rounded-2xl rounded-tl-sm px-4 py-3 border">
                  <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
                  <span className="text-sm text-muted-foreground">Painting your image...</span>
                </div>
              </div>
            )}

            {videoLoading && (
              <div className="flex gap-3">
                <img src="/ksk-logo.png" alt="KSK AI" className="h-9 w-9 rounded-full object-cover border-2 border-background shrink-0" />
                <div className="flex items-center gap-2 bg-muted rounded-2xl rounded-tl-sm px-4 py-3 border">
                  <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
                  <span className="text-sm text-muted-foreground">Rendering your video — this can take 30-90 seconds...</span>
                </div>
              </div>
            )}

            {/* Study mode — flashcards inline */}
            {mode === 'study' && (
              <div className="pt-4">
                <FlashcardStudy />
              </div>
            )}

            {/* Starter prompts when chat is short and not in study mode */}
            {messages.length <= 1 && mode !== 'study' && (
              <div className="space-y-3 pt-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
                  <Lightbulb className="h-3.5 w-3.5" /> Try one of these
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {STARTER_PROMPTS[mode].map((p, i) => (
                    <button key={i} onClick={() => pickStarterPrompt(p)} className="text-left text-sm px-3 py-2.5 rounded-lg border bg-card hover:bg-muted hover:border-emerald-500/40 transition group">
                      <span className="text-foreground">{p}</span>
                      <ChevronRight className="h-3.5 w-3.5 text-muted-foreground group-hover:text-emerald-600 inline ml-1" />
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Input area */}
        <div className="border-t bg-background/80 backdrop-blur-sm">
          <div className="max-w-3xl mx-auto px-4 py-3">
            {/* Preview chip (shown when an image or video is attached) */}
            {(attachedImage || attachedVideo) && (
              <div className="mb-2 flex items-center gap-2 rounded-lg border bg-muted/50 p-2">
                {attachedImage ? (
                  <img src={attachedImage} alt="To be sent" className="h-12 w-12 rounded object-cover border" />
                ) : (
                  <video src={attachedVideo!} className="h-12 w-12 rounded object-cover border" muted />
                )}
                <span className="text-xs text-muted-foreground flex-1">
                  {attachedImage ? 'Image' : 'Video'} attached — KSK AI will analyze it. Add a question, or just press send.
                </span>
                <button
                  onClick={() => { setAttachedImage(''); setAttachedVideo('') }}
                  className="text-xs text-muted-foreground hover:text-foreground p-1 rounded hover:bg-muted"
                  aria-label="Remove attached file"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
            <div className="flex items-end gap-2 rounded-2xl border bg-card p-2 focus-within:border-emerald-500/50 focus-within:ring-2 focus-within:ring-emerald-500/20 transition">
              {/* Hidden file input + paperclip button */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/gif,image/webp,video/mp4,video/webm,video/quicktime"
                onChange={handleFileChange}
                className="hidden"
              />
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="ghost"
                size="icon"
                className="h-9 w-9 rounded-xl shrink-0 text-muted-foreground hover:text-foreground"
                aria-label="Attach image or video"
                disabled={loading || imageLoading || videoLoading}
                title="Attach an image or video for KSK AI to analyze"
              >
                <Paperclip className="h-4 w-4" />
              </Button>
              <Textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  attachedImage ? 'Ask a question about this image (or just press send to describe it)...' :
                  attachedVideo ? 'Ask a question about this video (or just press send to describe it)...' :
                  mode === 'image' ? 'Describe the image you want to create...' :
                  mode === 'video' ? 'Describe the short video you want to create (cinematic shot, motion, mood)...' :
                  `Ask KSK AI anything about ${MODE_LABELS[mode].toLowerCase()}...`
                }
                className="min-h-[44px] max-h-[200px] resize-none border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 text-sm py-2.5"
                rows={1}
                disabled={loading || imageLoading || videoLoading}
              />
              <Button
                onClick={handleSend}
                disabled={(!input.trim() && !attachedImage && !attachedVideo) || loading || imageLoading || videoLoading}
                size="icon"
                className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shrink-0"
                aria-label="Send message"
              >
                {loading || imageLoading || videoLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground text-center mt-2">
              KSK AI protects Karan and the KSK Games Studio community. Be kind. &middot; Enter to send, Shift+Enter for newline &middot; 📎 attach an image or video to analyze &middot; ⚠️ KSK AI can make mistakes — verify important info
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
