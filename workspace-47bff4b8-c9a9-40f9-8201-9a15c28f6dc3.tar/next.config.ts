import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Allow Server Actions to work behind the preview gateway / reverse proxy.
  // The gateway forwards requests with a different `x-forwarded-host` than the
  // browser's `origin` header, which Next.js 16 rejects by default (CSRF guard).
  // We allowlist any origin so server actions (chatWithKSK, generateKSKImage)
  // succeed in the preview environment.
  serverActions: {
    allowedOrigins: ["*"],
  },
};

export default nextConfig;
